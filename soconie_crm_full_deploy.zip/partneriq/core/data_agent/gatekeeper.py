"""
B3. Decision Gatekeeper (DataIQ)
Deterministic Decision Gate: Determines whether dataset can be processed,
partially processed, or rejected to the Error Branch (B4).
Zero AI dependency - strictly evaluated by audit rules and Workspace thresholds.
"""

from typing import Dict, Any, List, Tuple, Optional
import pandas as pd


def evaluate_gatekeeper_decision(
    read_errors: List[Dict[str, Any]],
    raw_datasets: Dict[str, pd.DataFrame],
    plan: Dict[str, Any],
    workspace_config: Optional[Dict[str, Any]] = None
) -> Tuple[str, str, List[Dict[str, Any]]]:
    """
    Evaluates dataset readiness against Workspace quality thresholds.
    Returns:
        (decision: 'CAN_PROCESS' | 'PARTIAL' | 'CANNOT_PROCESS', notes: str, gate_errors: list)
    """
    cfg = workspace_config or {}
    max_err_threshold_pct = float(cfg.get("error_threshold_percent", 40.0))

    gate_errors = []

    # 1. Check for file level blocker errors (corruption, password, empty file)
    blockers = [e for e in read_errors if e.get("severity") == "BLOCKER"]
    if blockers:
        for b in blockers:
            gate_errors.append({
                "error_code": b.get("error_code", "ERR_FILE_BLOCKER"),
                "severity": "BLOCKER",
                "file_name": b.get("file_name", "Unknown"),
                "sheet_name": "Root",
                "row_index": 0,
                "col_name": "-",
                "offending_value": "<TỆP_HỎNG>",
                "cause": b.get("cause", "Tệp tin không thể đọc được."),
                "suggested_fix": b.get("suggested_fix", "Tải lại tệp dữ liệu nguyên vẹn.")
            })
        return "CANNOT_PROCESS", "Tệp dữ liệu bị hỏng hoặc rỗng, không thể bóc tách cấu trúc.", gate_errors

    # 2. Check if raw datasets are completely empty
    if not raw_datasets:
        gate_errors.append({
            "error_code": "ERR_NO_DATA",
            "severity": "BLOCKER",
            "file_name": "Tất cả",
            "sheet_name": "Root",
            "row_index": 0,
            "col_name": "-",
            "offending_value": "<NULL>",
            "cause": "Không trích xuất được bảng dữ liệu nào từ các tệp đã tải lên.",
            "suggested_fix": "Vui lòng kiểm tra định dạng tệp và thử tải lại dưới dạng CSV hoặc XLSX."
        })
        return "CANNOT_PROCESS", "Không có dữ liệu hợp lệ trong tệp tải lên.", gate_errors

    total_rows = sum(len(df) for df in raw_datasets.values())
    if total_rows == 0:
        gate_errors.append({
            "error_code": "ERR_ZERO_ROWS",
            "severity": "BLOCKER",
            "file_name": "Tất cả",
            "sheet_name": "Root",
            "row_index": 0,
            "col_name": "-",
            "offending_value": "0 dòng",
            "cause": "Tệp bảng tính có tiêu đề nhưng không chứa dòng dữ liệu nào.",
            "suggested_fix": "Cung cấp tệp có ít nhất 1 dòng bản ghi nghiệp vụ."
        })
        return "CANNOT_PROCESS", "Tệp dữ liệu không có dòng bản ghi nào.", gate_errors

    # 3. Check for essential column mappings (Key identification or Metric)
    col_mappings = plan.get("column_mappings", [])
    mapped_roles = {m.get("business_role") for m in col_mappings}

    has_identifier = any(r in mapped_roles for r in ["TRANSACTION_ID", "PARTNER_ID", "PARTNER_NAME", "PRODUCT_NAME"])
    has_metric = any(r in mapped_roles for r in ["TOTAL_AMOUNT", "QUANTITY", "UNIT_PRICE", "DEBT_BALANCE"])

    if not has_identifier and not has_metric:
        gate_errors.append({
            "error_code": "ERR_MISSING_KEY_COLUMNS",
            "severity": "BLOCKER",
            "file_name": list(raw_datasets.keys())[0],
            "sheet_name": "Header",
            "row_index": 1,
            "col_name": "All",
            "offending_value": "<THIẾU_CỘT_NGHIỆP_VỤ>",
            "cause": "Dữ liệu thiếu hoàn toàn các cột then chốt: không có cột định danh (mã/tên đối tác, mã đơn) và không có cột số liệu (tiền, số lượng, công nợ).",
            "suggested_fix": "Bổ sung mô tả ý nghĩa cột ở bước Nhập bối cảnh hoặc chuẩn bị tệp có chứa các cột thông tin nghiệp vụ cơ bản."
        })
        return "CANNOT_PROCESS", "Dữ liệu thiếu các cột nghiệp vụ then chốt để có thể phân tích.", gate_errors

    # 4. Check warning errors vs threshold
    warnings = [e for e in read_errors if e.get("severity") == "WARNING"]
    if warnings:
        for w in warnings:
            gate_errors.append({
                "error_code": w.get("error_code", "ERR_PARTIAL_READ"),
                "severity": "WARNING",
                "file_name": w.get("file_name", "Sheet"),
                "sheet_name": w.get("sheet_name", "Sheet"),
                "row_index": 0,
                "col_name": "-",
                "offending_value": "<CẢNH_BÁO>",
                "cause": w.get("cause", "Lỗi đọc một phần bảng tính."),
                "suggested_fix": w.get("suggested_fix", "Kiểm tra lại trang tính cảnh báo.")
            })
        return "PARTIAL", "Một số trang tính phụ bị lỗi nhưng dữ liệu chính vẫn đủ điều kiện xử lý.", gate_errors

    return "CAN_PROCESS", "Dữ liệu đáp ứng đầy đủ tiêu chí chất lượng và quy tắc nghiệp vụ.", []
