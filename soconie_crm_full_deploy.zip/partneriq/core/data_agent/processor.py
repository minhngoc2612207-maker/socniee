"""
B2.4 Deterministic Data Processor (DataIQ)
Executes data cleaning, deduplication, outlier detection, and logic constraint checks
using purely deterministic algorithms (pandas, numpy, rapidfuzz).
Ensures raw data remains immutable and logs every single cell mutation to the Change Log.
"""

import re
from datetime import datetime
from typing import Dict, Any, List, Tuple, Optional
import pandas as pd
import numpy as np

try:
    from rapidfuzz import fuzz
except ImportError:
    # Basic fallback if rapidfuzz is missing
    class fuzz:
        @staticmethod
        def token_sort_ratio(s1: str, s2: str) -> float:
            w1 = sorted(str(s1).lower().split())
            w2 = sorted(str(s2).lower().split())
            return 100.0 if w1 == w2 else 0.0


def clean_currency_number(val: Any) -> Tuple[Optional[float], bool]:
    """
    Cleans raw currency/numeric string into float.
    Returns: (cleaned_float, was_modified)
    """
    if val is None or pd.isna(val):
        return None, False

    if isinstance(val, (int, float)):
        return float(val), False

    s = str(val).strip()
    if not s:
        return None, False

    # Check if string contains currency or formatting symbols
    original = s
    # Remove currency words/symbols
    s = re.sub(r'(?i)(vnd|đ|usd|\$|đồng|dong)', '', s).strip()
    # Handle Vietnamese/European dot vs comma format: "15.000.000,00" or "15,000,000.00"
    if "." in s and "," in s:
        if s.rfind(",") > s.rfind("."):  # 15.000,50
            s = s.replace(".", "").replace(",", ".")
        else:  # 15,000.50
            s = s.replace(",", "")
    elif "," in s:
        parts = s.split(",")
        if len(parts) > 1 and all(len(p) == 3 for p in parts[1:]):  # Thousand separator: 15,000,000
            s = s.replace(",", "")
        else:
            s = s.replace(",", ".")
    elif "." in s:
        parts = s.split(".")
        if len(parts) > 1 and all(len(p) == 3 for p in parts[1:]):  # Thousand separator: 15.000.000
            s = s.replace(".", "")

    s = re.sub(r'[^\d\.\-]', '', s)
    try:
        f_val = float(s)
        was_mod = (str(val).strip() != str(f_val) and str(val).strip() != str(int(f_val)))
        return f_val, was_mod
    except Exception:
        return None, True


def standardize_date(val: Any) -> Tuple[Optional[str], bool, bool]:
    """
    Standardizes date into YYYY-MM-DD.
    Returns: (standardized_date_str, was_modified, is_invalid)
    """
    if val is None or pd.isna(val):
        return None, False, False

    if isinstance(val, (pd.Timestamp, datetime)):
        return val.strftime("%Y-%m-%d"), True, False

    s = str(val).strip()
    if not s:
        return None, False, False

    # Try common formats
    formats = [
        "%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%Y/%m/%d",
        "%d.%m.%Y", "%Y%m%d", "%m/%d/%Y"
    ]
    for fmt in formats:
        try:
            dt = datetime.strptime(s, fmt)
            res = dt.strftime("%Y-%m-%d")
            return res, (s != res), False
        except ValueError:
            continue

    # Try flexible dateutil parser
    try:
        dt = pd.to_datetime(s, dayfirst=True)
        res = dt.strftime("%Y-%m-%d")
        return res, (s != res), False
    except Exception:
        # Invalid date string (e.g. 31/02/2024)
        return s, False, True


def standardize_phone(val: Any) -> Tuple[Optional[str], bool, bool]:
    """
    Standardizes Vietnamese phone numbers into 10 digits starting with 0.
    Returns: (standardized_phone, was_modified, is_invalid)
    """
    if val is None or pd.isna(val):
        return None, False, False

    s = str(val).strip()
    digits = re.sub(r'\D', '', s)

    if digits.startswith("84") and len(digits) == 11:
        digits = "0" + digits[2:]

    if len(digits) == 10 and digits.startswith("0"):
        return digits, (s != digits), False

    # Invalid phone
    return s, False, True


def standardize_tax_id(val: Any) -> Tuple[Optional[str], bool, bool]:
    """
    Standardizes Vietnamese Tax ID (MST) into 10 or 13 digits.
    Returns: (standardized_mst, was_modified, is_invalid)
    """
    if val is None or pd.isna(val):
        return None, False, False

    s = str(val).strip()
    clean_mst = re.sub(r'[^0-9\-]', '', s)
    digits_only = re.sub(r'\D', '', clean_mst)

    if len(digits_only) == 10:
        return digits_only, (s != digits_only), False
    elif len(digits_only) == 13:
        formatted = f"{digits_only[:10]}-{digits_only[10:]}"
        return formatted, (s != formatted), False

    return s, False, True


def execute_data_processing(
    raw_datasets: Dict[str, pd.DataFrame],
    plan: Dict[str, Any],
    run_id: str,
    job_id: str,
    workspace_id: str = "ws-default"
) -> Tuple[Dict[str, pd.DataFrame], List[Dict[str, Any]], Dict[str, Any]]:
    """
    Executes the deterministic processing pipeline for all datasets.
    Returns:
        (clean_datasets, change_logs, processing_metrics)
    """
    clean_datasets = {}
    change_logs = []
    total_modifications = 0
    duplicate_rows_count = 0
    outlier_count = 0
    logic_error_count = 0

    cleaning_rules = plan.get("cleaning_rules", {})
    date_cols = set(cleaning_rules.get("date_columns", []))
    num_cols = set(cleaning_rules.get("numeric_columns", []))
    phone_cols = set(cleaning_rules.get("phone_columns", []))
    tax_cols = set(cleaning_rules.get("tax_id_columns", []))
    missing_strats = {item["column"]: item for item in cleaning_rules.get("missing_value_strategy", [])}

    dedup_rules = plan.get("deduplication_rules", {})
    exact_keys = dedup_rules.get("exact_keys", [])
    fuzzy_keys = dedup_rules.get("fuzzy_keys", [])

    outlier_rules = plan.get("outlier_rules", {})
    outlier_num_cols = set(outlier_rules.get("numeric_columns", []))
    iqr_multiplier = outlier_rules.get("multiplier", 1.5)

    logic_rules = plan.get("logic_rules", [])

    for ds_name, raw_df in raw_datasets.items():
        # Create detached copy for cleaning
        df = raw_df.copy(deep=True)
        file_part = ds_name.split("::")[0] if "::" in ds_name else ds_name
        sheet_part = ds_name.split("::")[1] if "::" in ds_name else "Main"

        # ------------------------------------------------------------------
        # 1. Format Standardization (Date, Number, Phone, MST)
        # ------------------------------------------------------------------
        for col in df.columns:
            # 1a. Date columns
            if col in date_cols or any(k in col.lower() for k in ["ngay", "date"]):
                for row_idx, val in df[col].items():
                    std_val, was_mod, is_inv = standardize_date(val)
                    if is_inv:
                        change_logs.append({
                            "run_id": run_id, "job_id": job_id, "workspace_id": workspace_id,
                            "file_name": file_part, "sheet_name": sheet_part, "row_index": int(row_idx) + 1,
                            "col_name": col, "old_value": val, "new_value": "NGÀY_KHÔNG_HỢP_LỆ",
                            "change_type": "FORMAT_DATE_ERROR",
                            "reason": f"Ngày '{val}' sai quy tắc lịch (ví dụ 31/02), đã gắn cờ kiểm tra",
                            "source": "RULE"
                        })
                        df.at[row_idx, col] = "NGÀY_KHÔNG_HỢP_LỆ"
                        total_modifications += 1
                    elif was_mod and std_val is not None:
                        change_logs.append({
                            "run_id": run_id, "job_id": job_id, "workspace_id": workspace_id,
                            "file_name": file_part, "sheet_name": sheet_part, "row_index": int(row_idx) + 1,
                            "col_name": col, "old_value": val, "new_value": std_val,
                            "change_type": "FORMAT_DATE",
                            "reason": "Chuẩn hóa định dạng ngày về chuẩn YYYY-MM-DD",
                            "source": "RULE"
                        })
                        df.at[row_idx, col] = std_val
                        total_modifications += 1

            # 1b. Numeric columns
            elif col in num_cols or any(k in col.lower() for k in ["tien", "gia", "luong", "amount", "price", "revenue", "cong_no"]):
                for row_idx, val in df[col].items():
                    num_val, was_mod = clean_currency_number(val)
                    if was_mod and num_val is not None:
                        change_logs.append({
                            "run_id": run_id, "job_id": job_id, "workspace_id": workspace_id,
                            "file_name": file_part, "sheet_name": sheet_part, "row_index": int(row_idx) + 1,
                            "col_name": col, "old_value": val, "new_value": num_val,
                            "change_type": "FORMAT_NUMBER",
                            "reason": "Loại bỏ ký tự tiền tệ và chuẩn hóa định dạng số",
                            "source": "RULE"
                        })
                        df.at[row_idx, col] = num_val
                        total_modifications += 1
                    elif num_val is not None:
                        df.at[row_idx, col] = num_val

            # 1c. Phone columns
            elif col in phone_cols or any(k in col.lower() for k in ["sdt", "phone", "tel"]):
                for row_idx, val in df[col].items():
                    phone_val, was_mod, is_inv = standardize_phone(val)
                    if was_mod and phone_val is not None:
                        change_logs.append({
                            "run_id": run_id, "job_id": job_id, "workspace_id": workspace_id,
                            "file_name": file_part, "sheet_name": sheet_part, "row_index": int(row_idx) + 1,
                            "col_name": col, "old_value": val, "new_value": phone_val,
                            "change_type": "PHONE_NORM",
                            "reason": "Chuẩn hóa số điện thoại 10 chữ số chuẩn Việt Nam",
                            "source": "RULE"
                        })
                        df.at[row_idx, col] = phone_val
                        total_modifications += 1

            # 1d. Tax ID columns
            elif col in tax_cols or "mst" in col.lower():
                for row_idx, val in df[col].items():
                    mst_val, was_mod, is_inv = standardize_tax_id(val)
                    if was_mod and mst_val is not None:
                        change_logs.append({
                            "run_id": run_id, "job_id": job_id, "workspace_id": workspace_id,
                            "file_name": file_part, "sheet_name": sheet_part, "row_index": int(row_idx) + 1,
                            "col_name": col, "old_value": val, "new_value": mst_val,
                            "change_type": "TAX_NORM",
                            "reason": "Chuẩn hóa định dạng Mã số thuế (10 hoặc 13 số)",
                            "source": "RULE"
                        })
                        df.at[row_idx, col] = mst_val
                        total_modifications += 1

            # 1e. Missing values handling
            if col in missing_strats:
                strat = missing_strats[col]
                method = strat.get("strategy", "flag_unknown")
                for row_idx, val in df[col].items():
                    if val is None or pd.isna(val) or str(val).strip() == "":
                        fill_val = strat.get("default_value", "CHƯA XÁC ĐỊNH")
                        if method == "median" and pd.to_numeric(df[col], errors="coerce").dropna().count() > 0:
                            fill_val = float(round(pd.to_numeric(df[col], errors="coerce").dropna().median(), 2))
                        change_logs.append({
                            "run_id": run_id, "job_id": job_id, "workspace_id": workspace_id,
                            "file_name": file_part, "sheet_name": sheet_part, "row_index": int(row_idx) + 1,
                            "col_name": col, "old_value": "<NULL>", "new_value": fill_val,
                            "change_type": "MISSING_FILL",
                            "reason": f"Điền giá trị thiếu theo chiến lược {method}",
                            "source": "RULE"
                        })
                        df.at[row_idx, col] = fill_val
                        total_modifications += 1

        # ------------------------------------------------------------------
        # 2. Exact Deduplication
        # ------------------------------------------------------------------
        df["_is_duplicate"] = False
        df["_duplicate_note"] = ""

        for key_cols in exact_keys:
            valid_keys = [k for k in key_cols if k in df.columns]
            if valid_keys:
                dups = df.duplicated(subset=valid_keys, keep="first")
                for row_idx, is_dup in dups.items():
                    if is_dup:
                        df.at[row_idx, "_is_duplicate"] = True
                        df.at[row_idx, "_duplicate_note"] = f"Trùng khớp 100% theo khóa [{', '.join(valid_keys)}]"
                        duplicate_rows_count += 1
                        change_logs.append({
                            "run_id": run_id, "job_id": job_id, "workspace_id": workspace_id,
                            "file_name": file_part, "sheet_name": sheet_part, "row_index": int(row_idx) + 1,
                            "col_name": valid_keys[0], "old_value": df.at[row_idx, valid_keys[0]],
                            "new_value": "[TRÙNG LẶP]",
                            "change_type": "DEDUPLICATE_EXACT",
                            "reason": f"Gắn cờ trùng lặp bản ghi lặp lại theo khóa {valid_keys}",
                            "source": "RULE"
                        })

        # ------------------------------------------------------------------
        # 3. Fuzzy Deduplication (Entity names with rapidfuzz)
        # ------------------------------------------------------------------
        for f_rule in fuzzy_keys:
            col_name = f_rule.get("column")
            threshold = f_rule.get("threshold", 85)
            if col_name in df.columns:
                unique_names = [str(x).strip() for x in df[col_name].dropna().unique() if len(str(x).strip()) > 3]
                canonical_map = {}
                for i in range(len(unique_names)):
                    for j in range(i + 1, len(unique_names)):
                        name1, name2 = unique_names[i], unique_names[j]
                        score = fuzz.token_sort_ratio(name1, name2)
                        if score >= threshold:
                            canonical = name1 if len(name1) >= len(name2) else name2
                            canonical_map[name2] = (canonical, score)

                for row_idx, val in df[col_name].items():
                    s_val = str(val).strip()
                    if s_val in canonical_map:
                        canonical, score = canonical_map[s_val]
                        df.at[row_idx, "_duplicate_note"] = f"Tương đồng mờ {score:.0f}% với '{canonical}'"
                        change_logs.append({
                            "run_id": run_id, "job_id": job_id, "workspace_id": workspace_id,
                            "file_name": file_part, "sheet_name": sheet_part, "row_index": int(row_idx) + 1,
                            "col_name": col_name, "old_value": val, "new_value": canonical,
                            "change_type": "DEDUPLICATE_FUZZY",
                            "reason": f"Chuẩn hóa tên đại lý trùng mờ (độ tương đồng {score:.0f}%)",
                            "source": "RULE"
                        })
                        df.at[row_idx, col_name] = canonical
                        total_modifications += 1

        # ------------------------------------------------------------------
        # 4. Outlier Detection (IQR Method)
        # ------------------------------------------------------------------
        df["_is_outlier"] = False
        df["_outlier_reason"] = ""

        for col in df.columns:
            if col in outlier_num_cols or col in num_cols:
                num_s = pd.to_numeric(df[col], errors="coerce").dropna()
                if len(num_s) >= 4:
                    q1 = num_s.quantile(0.25)
                    q3 = num_s.quantile(0.75)
                    iqr = q3 - q1
                    lower_bound = q1 - (iqr_multiplier * iqr)
                    upper_bound = q3 + (iqr_multiplier * iqr)

                    for row_idx, val in df[col].items():
                        try:
                            f_val = float(val)
                            if (f_val < lower_bound or f_val > upper_bound) and f_val > 0:
                                df.at[row_idx, "_is_outlier"] = True
                                note = f"Giá trị {f_val:,.0f} vượt ngưỡng ngoại lai IQR [{lower_bound:,.0f} - {upper_bound:,.0f}]"
                                df.at[row_idx, "_outlier_reason"] = note
                                outlier_count += 1
                                change_logs.append({
                                    "run_id": run_id, "job_id": job_id, "workspace_id": workspace_id,
                                    "file_name": file_part, "sheet_name": sheet_part, "row_index": int(row_idx) + 1,
                                    "col_name": col, "old_value": val, "new_value": f"{val} [NGOẠI_LAI]",
                                    "change_type": "OUTLIER_FLAG",
                                    "reason": note,
                                    "source": "RULE"
                                })
                        except (ValueError, TypeError):
                            continue

        # ------------------------------------------------------------------
        # 5. Logical Constraints Checking (e.g. Total == Qty * Price)
        # ------------------------------------------------------------------
        df["_is_logic_error"] = False
        df["_logic_error_details"] = ""

        for l_rule in logic_rules:
            r_type = l_rule.get("type")
            if r_type == "EQUALITY_PRODUCT":
                tot_col = l_rule.get("total_col")
                q_col = l_rule.get("qty_col")
                p_col = l_rule.get("price_col")
                tol = l_rule.get("tolerance_pct", 0.05)

                if tot_col in df.columns and q_col in df.columns and p_col in df.columns:
                    for row_idx in df.index:
                        try:
                            tot_val = float(df.at[row_idx, tot_col])
                            q_val = float(df.at[row_idx, q_col])
                            p_val = float(df.at[row_idx, p_col])
                            expected = q_val * p_val
                            if expected > 0:
                                diff_pct = abs(tot_val - expected) / expected
                                if diff_pct > tol:
                                    df.at[row_idx, "_is_logic_error"] = True
                                    detail = f"Sai lệch toán học: Báo cáo {tot_val:,.0f} đ, Thực tế ({q_val:,.0f} * {p_val:,.0f}) = {expected:,.0f} đ (lệch {diff_pct*100:.1f}%)"
                                    df.at[row_idx, "_logic_error_details"] = detail
                                    logic_error_count += 1
                                    change_logs.append({
                                        "run_id": run_id, "job_id": job_id, "workspace_id": workspace_id,
                                        "file_name": file_part, "sheet_name": sheet_part, "row_index": int(row_idx) + 1,
                                        "col_name": tot_col, "old_value": tot_val, "new_value": expected,
                                        "change_type": "LOGIC_CORRECTION",
                                        "reason": detail,
                                        "source": "RULE"
                                    })
                        except (ValueError, TypeError):
                            continue

            elif r_type == "NON_NEGATIVE":
                for col in l_rule.get("columns", []):
                    if col in df.columns:
                        for row_idx, val in df[col].items():
                            try:
                                f_val = float(val)
                                if f_val < 0:
                                    df.at[row_idx, "_is_logic_error"] = True
                                    detail = f"Giá trị âm không hợp lệ đối với cột '{col}': {f_val}"
                                    df.at[row_idx, "_logic_error_details"] = detail
                                    logic_error_count += 1
                                    change_logs.append({
                                        "run_id": run_id, "job_id": job_id, "workspace_id": workspace_id,
                                        "file_name": file_part, "sheet_name": sheet_part, "row_index": int(row_idx) + 1,
                                        "col_name": col, "old_value": val, "new_value": abs(f_val),
                                        "change_type": "LOGIC_CORRECTION",
                                        "reason": detail,
                                        "source": "RULE"
                                    })
                            except (ValueError, TypeError):
                                continue

        clean_datasets[ds_name] = df

    metrics = {
        "total_modifications": total_modifications,
        "duplicate_rows_flagged": duplicate_rows_count,
        "outliers_detected": outlier_count,
        "logic_errors_flagged": logic_error_count,
        "total_change_log_entries": len(change_logs)
    }

    return clean_datasets, change_logs, metrics
