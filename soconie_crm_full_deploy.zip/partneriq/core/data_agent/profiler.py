"""
B2.2 Data Profiler & Privacy Masker (DataIQ)
Performs deterministic exploratory data profiling:
- Shape, data types, null percentage, cardinality (unique count)
- Descriptive statistics (mean, median, min, max, std, quartiles)
- Frequency distributions for categorical fields
- Automatic detection and masking of sensitive PII (MST, Phone, Email, Bank Account)
"""

import re
from typing import Dict, Any, List, Optional
import pandas as pd
import numpy as np


SENSITIVE_PATTERNS = {
    "mst": [r"mst", r"ma_so_thue", r"tax_id", r"taxid"],
    "phone": [r"sdt", r"so_dien_thoai", r"phone", r"mobile", r"tel"],
    "email": [r"email", r"mail", r"thu_dien_tu"],
    "bank_account": [r"stk", r"so_tai_khoan", r"bank_acc", r"tai_khoan_ngan_hang"]
}


def mask_sensitive_value(val: Any, pii_type: str) -> str:
    """Masks sensitive values for enterprise privacy."""
    if val is None or pd.isna(val):
        return ""
    s = str(val).strip()
    if not s:
        return ""

    if pii_type == "phone":
        clean_num = re.sub(r'\D', '', s)
        if len(clean_num) >= 7:
            return clean_num[:3] + "****" + clean_num[-3:]
        return "****"

    elif pii_type == "mst":
        clean_mst = re.sub(r'[^0-9\-]', '', s)
        if len(clean_mst) >= 6:
            return clean_mst[:4] + "***" + clean_mst[-3:]
        return "****"

    elif pii_type == "email":
        parts = s.split("@")
        if len(parts) == 2 and parts[0]:
            user = parts[0]
            masked_user = user[0] + "***" if len(user) > 1 else "***"
            return f"{masked_user}@{parts[1]}"
        return "***@***"

    elif pii_type == "bank_account":
        clean_acc = re.sub(r'\D', '', s)
        if len(clean_acc) >= 6:
            return clean_acc[:3] + "******" + clean_acc[-3:]
        return "******"

    return "***"


def detect_pii_type(col_name: str, sample_series: pd.Series) -> Optional[str]:
    """Detects whether a column contains sensitive PII."""
    c_lower = col_name.lower().replace(" ", "_")
    for pii_type, patterns in SENSITIVE_PATTERNS.items():
        if any(re.search(p, c_lower) for p in patterns):
            return pii_type

    # Value-based heuristic for phone and email
    non_null_samples = sample_series.dropna().astype(str).head(10).tolist()
    if non_null_samples:
        email_match = sum(1 for v in non_null_samples if re.match(r'^[\w\.-]+@[\w\.-]+\.\w+$', v))
        if email_match >= 3:
            return "email"

        phone_match = sum(1 for v in non_null_samples if re.match(r'^(\+?84|0)[35789]\d{8}$', re.sub(r'[\s\.\-]', '', v)))
        if phone_match >= 3:
            return "phone"

    return None


def profile_dataframe(df: pd.DataFrame, dataset_name: str, mask_sensitive: bool = True) -> Dict[str, Any]:
    """
    Computes statistical profiling for a single DataFrame.
    """
    row_count = len(df)
    col_count = len(df.columns)

    columns_profile = {}
    detected_pii_cols = {}

    for col in df.columns:
        series = df[col]
        null_count = int(series.isna().sum())
        null_pct = round((null_count / row_count * 100), 2) if row_count > 0 else 0.0
        unique_count = int(series.nunique(dropna=True))

        pii_type = detect_pii_type(col, series)
        if pii_type:
            detected_pii_cols[col] = pii_type

        # Infer general data type
        col_type = "string"
        numeric_series = pd.to_numeric(series.astype(str).str.replace(r'[\s,đVND$]', '', regex=True), errors="coerce")
        valid_num_count = numeric_series.dropna().count()

        if valid_num_count > 0 and (valid_num_count / max(row_count - null_count, 1)) > 0.7:
            col_type = "numeric"
        elif "ngay" in col.lower() or "date" in col.lower() or "time" in col.lower():
            col_type = "datetime"

        stats: Dict[str, Any] = {
            "type": col_type,
            "null_count": null_count,
            "null_pct": null_pct,
            "unique_count": unique_count,
            "is_sensitive": pii_type is not None,
            "pii_type": pii_type
        }

        # Numeric stats
        if col_type == "numeric":
            clean_num = numeric_series.dropna()
            if not clean_num.empty:
                stats["min"] = float(round(clean_num.min(), 2))
                stats["max"] = float(round(clean_num.max(), 2))
                stats["mean"] = float(round(clean_num.mean(), 2))
                stats["median"] = float(round(clean_num.median(), 2))
                stats["std"] = float(round(clean_num.std(), 2)) if len(clean_num) > 1 else 0.0
                stats["q1"] = float(round(clean_num.quantile(0.25), 2))
                stats["q3"] = float(round(clean_num.quantile(0.75), 2))

        # Sample values (masked if sensitive)
        raw_samples = series.dropna().unique()[:5].tolist()
        if mask_sensitive and pii_type:
            stats["sample_values"] = [mask_sensitive_value(v, pii_type) for v in raw_samples]
        else:
            stats["sample_values"] = [str(v) for v in raw_samples]

        # Top frequent values for low cardinality
        if unique_count <= 20 and row_count > 0:
            top_val_counts = series.value_counts(dropna=True).head(5)
            stats["top_frequencies"] = {
                (mask_sensitive_value(k, pii_type) if (mask_sensitive and pii_type) else str(k)): int(v)
                for k, v in top_val_counts.items()
            }

        columns_profile[col] = stats

    return {
        "dataset_name": dataset_name,
        "row_count": row_count,
        "col_count": col_count,
        "sensitive_columns": detected_pii_cols,
        "columns": columns_profile
    }


def profile_all_datasets(datasets: Dict[str, pd.DataFrame], mask_sensitive: bool = True) -> Dict[str, Any]:
    """
    Profiles all loaded datasets and produces a consolidated profile summary.
    """
    profiles = {}
    total_rows = 0
    total_cols = 0
    all_sensitive = []

    for name, df in datasets.items():
        prof = profile_dataframe(df, name, mask_sensitive=mask_sensitive)
        profiles[name] = prof
        total_rows += prof["row_count"]
        total_cols += prof["col_count"]
        for c, t in prof["sensitive_columns"].items():
            all_sensitive.append({"dataset": name, "column": c, "pii_type": t})

    return {
        "summary": {
            "total_datasets": len(datasets),
            "total_rows": total_rows,
            "total_columns": total_cols,
            "sensitive_fields_detected": len(all_sensitive),
            "sensitive_fields": all_sensitive,
            "privacy_masking_applied": mask_sensitive
        },
        "datasets": profiles
    }
