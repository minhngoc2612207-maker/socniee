"""
B2.1 Multi-format Data Reader (DataIQ)
Reads CSV, XLSX, XLS, JSON, PDF, DOCX, TXT.
Features:
- Automatic encoding detection (UTF-8, UTF-8-SIG, Latin-1, CP1258, Windows-1252)
- Automatic delimiter detection (comma, semicolon, tab, pipe)
- Multi-sheet Excel parsing with openpyxl
- Table extraction from PDF (pypdf) and Word (python-docx)
- Immutable raw data retention with structured diagnostics
"""

import os
import re
import csv
import json
from typing import Dict, Any, List, Tuple, Optional
import pandas as pd
import numpy as np

# Optional readers
try:
    import pypdf
except ImportError:
    pypdf = None

try:
    import docx
except ImportError:
    docx = None


ENCODINGS_TO_TRY = ["utf-8", "utf-8-sig", "cp1258", "latin-1", "iso-8859-1", "windows-1252"]


def detect_csv_delimiter_and_encoding(file_path: str) -> Tuple[str, str]:
    """Detects encoding and delimiter of a text/csv file."""
    detected_encoding = "utf-8"
    sample_text = ""

    for enc in ENCODINGS_TO_TRY:
        try:
            with open(file_path, "r", encoding=enc) as f:
                sample_text = f.read(8192)
                detected_encoding = enc
                break
        except Exception:
            continue

    if not sample_text:
        return ",", "utf-8"

    # Delimiter detection
    try:
        sniffer = csv.Sniffer()
        dialect = sniffer.sniff(sample_text, delimiters=[",", ";", "\t", "|"])
        delimiter = dialect.delimiter
    except Exception:
        # Fallback count
        counts = {
            ",": sample_text.count(","),
            ";": sample_text.count(";"),
            "\t": sample_text.count("\t"),
            "|": sample_text.count("|")
        }
        delimiter = max(counts, key=counts.get)
        if counts[delimiter] == 0:
            delimiter = ","

    return delimiter, detected_encoding


def read_data_file(file_path: str, original_filename: Optional[str] = None) -> Dict[str, Any]:
    """
    Reads a single data file into one or more DataFrames.
    Returns:
        {
            "success": bool,
            "filename": str,
            "file_type": str,
            "sheets": { sheet_name: pd.DataFrame },
            "errors": [ { error_code, severity, cause, suggested_fix } ],
            "meta": { "total_rows": int, "total_cols": int, "sheet_names": [...] }
        }
    """
    filename = original_filename or os.path.basename(file_path)
    ext = os.path.splitext(filename)[1].lower()

    result = {
        "success": False,
        "filename": filename,
        "file_type": ext.lstrip("."),
        "sheets": {},
        "errors": [],
        "meta": {"total_rows": 0, "total_cols": 0, "sheet_names": []}
    }

    if not os.path.exists(file_path):
        result["errors"].append({
            "error_code": "ERR_FILE_NOT_FOUND",
            "severity": "BLOCKER",
            "cause": f"Tệp không tồn tại trên máy chủ: {filename}",
            "suggested_fix": "Vui lòng tải lại tệp tin."
        })
        return result

    file_size = os.path.getsize(file_path)
    if file_size == 0:
        result["errors"].append({
            "error_code": "ERR_FILE_EMPTY",
            "severity": "BLOCKER",
            "cause": f"Tệp '{filename}' hoàn toàn rỗng (0 bytes).",
            "suggested_fix": "Vui lòng kiểm tra lại tệp nguồn và chọn tệp có chứa dữ liệu."
        })
        return result

    try:
        if ext in [".xlsx", ".xls"]:
            # Excel reader: process all sheets
            excel_file = pd.ExcelFile(file_path, engine="openpyxl" if ext == ".xlsx" else None)
            sheet_names = excel_file.sheet_names

            if not sheet_names:
                result["errors"].append({
                    "error_code": "ERR_NO_SHEETS",
                    "severity": "BLOCKER",
                    "cause": "Tệp Excel không có trang tính (sheet) nào.",
                    "suggested_fix": "Mở tệp bằng Excel và lưu lại ít nhất 1 bảng dữ liệu."
                })
                return result

            for s_name in sheet_names:
                try:
                    df = pd.read_excel(excel_file, sheet_name=s_name)
                    # Clean empty rows/cols
                    df = df.dropna(how="all").dropna(axis=1, how="all")
                    if not df.empty:
                        # Ensure column names are strings
                        df.columns = [str(c).strip() for c in df.columns]
                        result["sheets"][s_name] = df
                except Exception as sheet_err:
                    result["errors"].append({
                        "error_code": "ERR_SHEET_READ_FAIL",
                        "severity": "WARNING",
                        "cause": f"Không thể đọc sheet '{s_name}': {str(sheet_err)}",
                        "suggested_fix": "Kiểm tra định dạng các ô hoặc mật khẩu bảo vệ sheet."
                    })

        elif ext == ".csv":
            delimiter, encoding = detect_csv_delimiter_and_encoding(file_path)
            try:
                df = pd.read_csv(file_path, delimiter=delimiter, encoding=encoding, low_memory=False)
                df = df.dropna(how="all").dropna(axis=1, how="all")
                df.columns = [str(c).strip() for c in df.columns]
                result["sheets"]["Main"] = df
            except Exception as e:
                # Try fallback python engine
                df = pd.read_csv(file_path, engine="python", encoding=encoding, on_bad_lines="skip")
                df = df.dropna(how="all").dropna(axis=1, how="all")
                df.columns = [str(c).strip() for c in df.columns]
                result["sheets"]["Main"] = df

        elif ext == ".json":
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                data = json.load(f)
            if isinstance(data, list):
                df = pd.json_normalize(data)
                result["sheets"]["Main"] = df
            elif isinstance(data, dict):
                # Check if dict of lists
                if all(isinstance(v, list) for v in data.values()):
                    for k, v in data.items():
                        result["sheets"][k] = pd.json_normalize(v)
                else:
                    df = pd.json_normalize([data])
                    result["sheets"]["Main"] = df

        elif ext == ".pdf":
            if pypdf is None:
                raise ImportError("Thư viện pypdf chưa được cài đặt.")
            reader = pypdf.PdfReader(file_path)
            all_text_lines = []
            for page in reader.pages:
                text = page.extract_text() or ""
                for line in text.split("\n"):
                    l_str = line.strip()
                    if l_str:
                        all_text_lines.append(l_str)

            # Heuristic table parse from lines (delimiters: tab, double space, or pipe)
            parsed_rows = []
            for line in all_text_lines:
                parts = re.split(r'\t|\s{2,}|\|', line)
                parts = [p.strip() for p in parts if p.strip()]
                if len(parts) >= 2:
                    parsed_rows.append(parts)

            if parsed_rows and len(parsed_rows) > 1:
                # Normalize column lengths
                max_cols = max(len(r) for r in parsed_rows)
                header = [f"Col_{i+1}" for i in range(max_cols)]
                if len(parsed_rows[0]) == max_cols:
                    header = [str(c) for c in parsed_rows[0]]
                    parsed_rows = parsed_rows[1:]
                padded = [r + [None] * (max_cols - len(r)) for r in parsed_rows]
                df = pd.DataFrame(padded, columns=header)
                result["sheets"]["PDF_Extracted"] = df
            else:
                result["errors"].append({
                    "error_code": "ERR_PDF_NO_TABLE",
                    "severity": "WARNING",
                    "cause": "Tệp PDF không chứa cấu trúc bảng rõ ràng để trích xuất số liệu.",
                    "suggested_fix": "Ưu tiên tải file Excel hoặc CSV để đạt độ chính xác tính toán cao nhất."
                })

        elif ext in [".docx", ".doc"]:
            if docx is None:
                raise ImportError("Thư viện python-docx chưa được cài đặt.")
            doc = docx.Document(file_path)
            table_idx = 1
            for table in doc.tables:
                rows_data = []
                for row in table.rows:
                    row_cells = [cell.text.strip() for cell in row.cells]
                    if any(row_cells):
                        rows_data.append(row_cells)
                if len(rows_data) > 1:
                    headers = [f"Col_{i+1}" for i in range(len(rows_data[0]))]
                    if all(isinstance(c, str) for c in rows_data[0]):
                        headers = rows_data[0]
                        rows_data = rows_data[1:]
                    df = pd.DataFrame(rows_data, columns=headers)
                    result["sheets"][f"Table_{table_idx}"] = df
                    table_idx += 1

            if not result["sheets"]:
                result["errors"].append({
                    "error_code": "ERR_DOCX_NO_TABLE",
                    "severity": "WARNING",
                    "cause": "Tệp DOCX không chứa bảng dữ liệu (Table) có thể xử lý.",
                    "suggested_fix": "Vui lòng xuất bảng sang file XLSX hoặc CSV."
                })

        elif ext == ".txt":
            delimiter, encoding = detect_csv_delimiter_and_encoding(file_path)
            df = pd.read_csv(file_path, delimiter=delimiter, encoding=encoding, on_bad_lines="skip")
            df = df.dropna(how="all").dropna(axis=1, how="all")
            df.columns = [str(c).strip() for c in df.columns]
            result["sheets"]["TextData"] = df

    except Exception as e:
        err_msg = str(e)
        result["errors"].append({
            "error_code": "ERR_FILE_CORRUPT",
            "severity": "BLOCKER",
            "cause": f"Lỗi đọc tệp '{filename}': Tệp bị hỏng cấu trúc hoặc mã hóa không hợp lệ ({err_msg}).",
            "suggested_fix": "Mở tệp bằng phần mềm gốc, kiểm tra xem có bị lỗi hoặc đặt mật khẩu không, sau đó lưu lại dưới định dạng XLSX hoặc CSV UTF-8 chuẩn."
        })
        return result

    # Check if sheets were extracted
    if not result["sheets"]:
        if not result["errors"]:
            result["errors"].append({
                "error_code": "ERR_DATA_EMPTY",
                "severity": "BLOCKER",
                "cause": f"Không tìm thấy dòng dữ liệu hợp lệ nào trong tệp '{filename}'.",
                "suggested_fix": "Kiểm tra lại nội dung bảng tính và đảm bảo tệp có ít nhất 1 hàng tiêu đề và các dòng dữ liệu."
            })
        return result

    # Calculate meta stats
    total_rows = sum(len(df) for df in result["sheets"].values())
    total_cols = max((len(df.columns) for df in result["sheets"].values()), default=0)
    sheet_names_list = list(result["sheets"].keys())

    result["success"] = True
    result["meta"] = {
        "total_rows": total_rows,
        "total_cols": total_cols,
        "sheet_names": sheet_names_list
    }
    return result


def read_all_job_files(file_records: List[Dict[str, Any]]) -> Tuple[Dict[str, pd.DataFrame], List[Dict[str, Any]]]:
    """
    Reads all uploaded files for a job.
    Returns:
        (datasets_dict, all_errors)
        datasets_dict format: { f"{filename}::{sheet_name}": df }
    """
    datasets = {}
    all_errors = []

    for f_rec in file_records:
        path = f_rec.get("file_path", "")
        fname = f_rec.get("original_filename") or f_rec.get("filename") or os.path.basename(path)
        read_res = read_data_file(path, original_filename=fname)

        if not read_res["success"] or read_res["errors"]:
            for err in read_res["errors"]:
                err["file_name"] = fname
                all_errors.append(err)

        if read_res["success"]:
            for s_name, df in read_res["sheets"].items():
                dataset_key = f"{fname}::{s_name}" if len(read_res["sheets"]) > 1 else fname
                # Create a detached copy to ensure immutability
                datasets[dataset_key] = df.copy(deep=True)

    return datasets, all_errors
