"""
B7. Exporter & Strategic Executive Briefing Module (DataIQ)
Produces:
1. Multi-sheet Excel workbook (Clean Data, Change Log, Findings, Excluded/Flagged).
2. Sanitized CSV with CSV injection protection (=, +, -, @, \\t, \\r escaping).
3. Branded Executive PDF Report using ReportLab with Workspace branding and evidence appendix.
4. Complete machine-readable JSON package.
5. Gemini-drafted corporate executive email summary.
"""

import os
import io
import json
import re
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple
import pandas as pd
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors

from partneriq.repository import (
    get_job, get_run, get_change_logs, get_findings, get_feedbacks,
    get_evaluation, get_workspace, update_job_status, log_audit
)
from agent.llm_client import call_gemini


EXECUTIVE_EMAIL_PROMPT = """
Bạn là Thư ký Chiến lược kiêm Trưởng nhóm Phân tích Dữ liệu Doanh nghiệp.
Hãy soạn thảo bản Email Nháp (Corporate Email Draft) gửi Tổng Giám đốc / Ban Lãnh đạo
báo cáo kết quả xử lý và phân tích dữ liệu cho bài toán: "{problem_statement}".

YÊU CẦU:
- Văn phong chuẩn mực, súc tích, trang trọng theo chuẩn doanh nghiệp lớn.
- BẮT BUỘC chỉ sử dụng số liệu đã được kiểm duyệt:
  * Doanh thu thực tế sau chuẩn hóa: {adjusted_rev:,.0f} đ
  * Số tiền sai lệch phát hiện: {distortion:,.0f} đ
  * Số phát hiện rủi ro trọng yếu: {findings_count} phát hiện
- Nêu rõ 3 hành động cụ thể cần Ban Lãnh đạo phê duyệt ngay.
"""


def sanitize_csv_cell(val: Any) -> Any:
    """Escapes cells starting with formula trigger characters to prevent CSV Injection."""
    if val is None:
        return ""
    s = str(val)
    if s and s[0] in ['=', '+', '-', '@', '\t', '\r']:
        return f"'{s}"
    return val


def export_clean_data_to_csv(df: pd.DataFrame) -> io.BytesIO:
    """Exports clean dataframe to CSV with injection escaping."""
    safe_df = df.copy()
    for col in safe_df.columns:
        safe_df[col] = safe_df[col].apply(sanitize_csv_cell)

    buf = io.BytesIO()
    safe_df.to_csv(buf, index=False, encoding="utf-8-sig")
    buf.seek(0)
    return buf


def export_to_multisheet_excel(
    clean_datasets: Dict[str, pd.DataFrame],
    change_logs: List[Dict[str, Any]],
    findings: List[Dict[str, Any]],
    job_title: str,
    brand_color_hex: str = "#4f46e5"
) -> io.BytesIO:
    """
    Exports clean data, change logs, findings, and flagged records into a styled multi-sheet Excel workbook.
    """
    wb = openpyxl.Workbook()
    # Remove default sheet
    wb.remove(wb.active)

    # Styles
    clean_hex = brand_color_hex.lstrip("#")
    brand_fill = PatternFill(start_color=clean_hex, end_color=clean_hex, fill_type="solid")
    brand_font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    align_center = Alignment(horizontal="center", vertical="center", wrap_text=True)
    align_left = Alignment(horizontal="left", vertical="center")
    align_right = Alignment(horizontal="right", vertical="center")
    thin_border = Border(
        left=Side(style='thin', color='E5E7EB'),
        right=Side(style='thin', color='E5E7EB'),
        top=Side(style='thin', color='E5E7EB'),
        bottom=Side(style='thin', color='E5E7EB')
    )

    # -------------------------------------------------------------
    # Sheet 1: Dữ liệu sạch (Clean Data)
    # -------------------------------------------------------------
    ws_clean = wb.create_sheet(title="Dữ liệu sạch")
    main_df = list(clean_datasets.values())[0] if clean_datasets else pd.DataFrame()

    # Filter out system helper columns for clean view
    visible_cols = [c for c in main_df.columns if not c.startswith("_")]
    ws_clean.append(visible_cols)
    ws_clean.row_dimensions[1].height = 26

    for c_idx in range(1, len(visible_cols) + 1):
        cell = ws_clean.cell(row=1, column=c_idx)
        cell.fill = brand_fill
        cell.font = brand_font
        cell.alignment = align_center

    for _, row in main_df.iterrows():
        row_vals = [sanitize_csv_cell(row[c]) for c in visible_cols]
        ws_clean.append(row_vals)
        cur_row = ws_clean.max_row
        ws_clean.row_dimensions[cur_row].height = 20
        for c_idx in range(1, len(visible_cols) + 1):
            c = ws_clean.cell(row=cur_row, column=c_idx)
            c.border = thin_border
            if isinstance(row_vals[c_idx - 1], (int, float)):
                c.alignment = align_right
            else:
                c.alignment = align_left

    # Auto column width
    for col in ws_clean.columns:
        max_len = max(len(str(cell.value or '')) for cell in col)
        col_letter = get_column_letter(col[0].column)
        ws_clean.column_dimensions[col_letter].width = min(max(max_len + 3, 12), 40)

    # -------------------------------------------------------------
    # Sheet 2: Change Log
    # -------------------------------------------------------------
    ws_logs = wb.create_sheet(title="Change Log")
    log_headers = ["STT", "Tệp", "Sheet", "Tọa Độ (Dòng:Cột)", "Giá Trị Cũ", "Giá Trị Mới", "Loại Hiệu Chỉnh", "Lý Do", "Nguồn"]
    ws_logs.append(log_headers)
    ws_logs.row_dimensions[1].height = 26

    for c_idx in range(1, len(log_headers) + 1):
        cell = ws_logs.cell(row=1, column=c_idx)
        cell.fill = PatternFill(start_color="3B82F6", end_color="3B82F6", fill_type="solid")
        cell.font = brand_font
        cell.alignment = align_center

    for idx, log in enumerate(change_logs, 1):
        coord = f"Dòng {log.get('row_index', 0)} : Cột {log.get('col_name', '-')}"
        ws_logs.append([
            idx,
            log.get("file_name", "-"),
            log.get("sheet_name", "-"),
            coord,
            str(log.get("old_value", "")),
            str(log.get("new_value", "")),
            log.get("change_type", "FORMAT"),
            log.get("reason", ""),
            log.get("source", "RULE")
        ])
        cur_row = ws_logs.max_row
        ws_logs.row_dimensions[cur_row].height = 20
        for c_idx in range(1, len(log_headers) + 1):
            c = ws_logs.cell(row=cur_row, column=c_idx)
            c.border = thin_border

    for col in ws_logs.columns:
        max_len = max(len(str(cell.value or '')) for cell in col)
        col_letter = get_column_letter(col[0].column)
        ws_logs.column_dimensions[col_letter].width = min(max(max_len + 3, 12), 45)

    # -------------------------------------------------------------
    # Sheet 3: Phát hiện & Rủi ro
    # -------------------------------------------------------------
    ws_find = wb.create_sheet(title="Phát hiện & Rủi ro")
    find_headers = ["Mã", "Tiêu Đề", "Mức Độ", "Nhóm", "Bản Chất & Thiệt Hại", "Ước Tính Tác Động", "Khuyến Nghị Xử Lý"]
    ws_find.append(find_headers)
    ws_find.row_dimensions[1].height = 26

    for c_idx in range(1, len(find_headers) + 1):
        cell = ws_find.cell(row=1, column=c_idx)
        cell.fill = PatternFill(start_color="EF4444", end_color="EF4444", fill_type="solid")
        cell.font = brand_font
        cell.alignment = align_center

    for f in findings:
        ws_find.append([
            f.get("id"),
            f.get("title"),
            f.get("severity"),
            f.get("category"),
            f.get("description"),
            f.get("impact_estimate"),
            f.get("recommendation")
        ])
        cur_row = ws_find.max_row
        ws_find.row_dimensions[cur_row].height = 24
        for c_idx in range(1, len(find_headers) + 1):
            c = ws_find.cell(row=cur_row, column=c_idx)
            c.border = thin_border

    for col in ws_find.columns:
        max_len = max(len(str(cell.value or '')) for cell in col)
        col_letter = get_column_letter(col[0].column)
        ws_find.column_dimensions[col_letter].width = min(max(max_len + 3, 12), 50)

    # -------------------------------------------------------------
    # Sheet 4: Bản ghi bị loại & Gắn cờ
    # -------------------------------------------------------------
    ws_flagged = wb.create_sheet(title="Bản ghi bị gắn cờ")
    flag_mask = pd.Series(False, index=main_df.index) if main_df is not None else None
    if main_df is not None:
        for col_flag in ["_is_duplicate", "_is_outlier", "_is_logic_error"]:
            if col_flag in main_df.columns:
                flag_mask |= (main_df[col_flag] == True)
    flagged_df = main_df[flag_mask] if (main_df is not None and flag_mask is not None) else pd.DataFrame()

    if not flagged_df.empty:
        ws_flagged.append(list(flagged_df.columns))
        for _, row in flagged_df.iterrows():
            ws_flagged.append([str(v) for v in row.values])
    else:
        ws_flagged.append(["Thông báo"])
        ws_flagged.append(["Không có dòng bản ghi nào bị loại hoặc gắn cờ lỗi nghiêm trọng."])

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf


def export_executive_report_to_pdf(
    job_id: str,
    run_id: str,
    workspace_id: str = "ws-default"
) -> io.BytesIO:
    """
    Generates branded Executive PDF report using ReportLab.
    Includes Workspace styling, executive summary, KPI highlights, findings, and evidence tables.
    """
    job = get_job(job_id)
    run = get_run(run_id)
    ws = get_workspace(workspace_id)
    findings = get_findings(run_id)

    ws_name = ws.get("name", "Đại Thành Group") if ws else "Đại Thành Group"
    ws_color = ws.get("brand_color", "#4f46e5") if ws else "#4f46e5"
    preview = run.get("clean_data_preview", {}) if run else {}
    kpis = preview.get("kpis", {})

    buf = io.BytesIO()
    doc = SimpleDocTemplate(
        buf,
        pagesize=A4,
        rightMargin=36,
        leftMargin=36,
        topMargin=36,
        bottomMargin=36
    )

    styles = getSampleStyleSheet()
    primary_color = colors.HexColor(ws_color)

    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=20,
        leading=24,
        textColor=primary_color,
        spaceAfter=10
    )
    subtitle_style = ParagraphStyle(
        'DocSubtitle',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=10,
        leading=14,
        textColor=colors.HexColor('#6B7280'),
        spaceAfter=15
    )
    h2_style = ParagraphStyle(
        'SectionH2',
        parent=styles['Heading2'],
        fontName='Helvetica-Bold',
        fontSize=13,
        leading=16,
        textColor=primary_color,
        spaceBefore=12,
        spaceAfter=6
    )
    body_style = ParagraphStyle(
        'BodyTextCustom',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=9,
        leading=13,
        textColor=colors.HexColor('#1F2937'),
        spaceAfter=6
    )

    story = []

    # Title & Header
    story.append(Paragraph(f"{ws_name.upper()} - BÁO CÁO ĐIỀU HÀNH", subtitle_style))
    story.append(Paragraph(f"Báo Cáo Xử Lý Dữ Liệu & Rủi Ro Chiến Lược: {job.get('title', '')}", title_style))
    story.append(Paragraph(
        f"Mã phiên: <b>{job_id}</b> | Phiên bản: <b>v{run.get('version', 1)}</b> | Ngày xuất: <b>{datetime.now().strftime('%d/%m/%Y %H:%M')}</b>",
        subtitle_style
    ))
    story.append(Spacer(1, 10))

    # KPI Summary Table
    story.append(Paragraph("1. CHỈ SỐ TÀI CHÍNH & VẬN HÀNH TRỌNG TÂM", h2_style))
    kpi_data = [
        ["Chỉ Số Nghiệp Vụ", "Số Liệu Thực Chứng", "Đánh Giá & Tác Động"],
        ["Doanh thu theo sổ ban đầu", f"{kpis.get('raw_total_revenue', 0):,.0f} đ", "Số liệu chưa qua kiểm định"],
        ["Doanh thu thực tế đã chuẩn hóa", f"{kpis.get('adjusted_revenue', 0):,.0f} đ", "Đã loại trừ trùng lặp & ngoại lai"],
        ["Độ lệch do sai số & ngoại lai", f"{kpis.get('outlier_distortion_amount', 0):,.0f} đ", "Gây méo mó kết quả kinh doanh"],
        ["Tổng số phát hiện rủi ro", f"{kpis.get('total_findings_count', 0)} phát hiện", f"{kpis.get('critical_findings_count', 0)} rủi ro mức độ Nghiêm trọng"]
    ]
    t_kpi = Table(kpi_data, colWidths=[180, 150, 190])
    t_kpi.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), primary_color),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 9),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#E5E7EB')),
        ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#F9FAFB')),
        ('TOPPADDING', (0, 0), (-1, -1), 5),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
    ]))
    story.append(t_kpi)
    story.append(Spacer(1, 15))

    # Findings
    story.append(Paragraph("2. DANH MỤC PHÁT HIỆN RỦI RO & BẰNG CHỨNG (FINDINGS)", h2_style))
    find_table_data = [["Mã", "Tiêu Đề Phát Hiện", "Mức Độ", "Ước Tính Thiệt Hại"]]
    for f in findings:
        find_table_data.append([
            f.get("id"),
            f.get("title")[:45] + ("..." if len(f.get("title", "")) > 45 else ""),
            f.get("severity"),
            f.get("impact_estimate")[:35] + ("..." if len(f.get("impact_estimate", "")) > 35 else "")
        ])

    t_find = Table(find_table_data, colWidths=[65, 230, 85, 140])
    t_find.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#DC2626')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 8),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#E5E7EB')),
        ('TOPPADDING', (0, 0), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
    ]))
    story.append(t_find)
    story.append(Spacer(1, 15))

    # Executive Markdown Summary
    story.append(Paragraph("3. TỔNG LUẬN CHIẾN LƯỢC & HÀNH ĐỘNG ĐỀ XUẤT", h2_style))
    rep_md = run.get("report_markdown", "") if run else ""
    # Strip markdown headers for clean PDF paragraph rendering
    clean_lines = [l.strip() for l in rep_md.split("\n") if l.strip() and not l.startswith("#")]
    for line in clean_lines[:15]:
        story.append(Paragraph(line, body_style))

    story.append(Spacer(1, 20))
    story.append(Paragraph("<i>Báo cáo được khởi tạo tự động bởi Hệ thống AI DataIQ. Bản quyền thuộc Workspace.</i>", subtitle_style))

    doc.build(story)
    buf.seek(0)
    return buf


def generate_executive_email_draft(
    job_id: str,
    run_id: str,
    user_name: str = "Nguyễn Văn An"
) -> str:
    """Generates corporate email draft via Gemini."""
    job = get_job(job_id)
    run = get_run(run_id)
    preview = run.get("clean_data_preview", {}) if run else {}
    kpis = preview.get("kpis", {})

    prompt = EXECUTIVE_EMAIL_PROMPT.format(
        problem_statement=job.get("problem_statement", ""),
        adjusted_rev=kpis.get("adjusted_revenue", 0),
        distortion=kpis.get("outlier_distortion_amount", 0),
        findings_count=kpis.get("total_findings_count", 0)
    )

    res = call_gemini(prompt=prompt, temperature=0.3, max_tokens=1500)
    if res.get("success") and res.get("text") and len(res["text"].strip()) > 50:
        return res["text"].strip()

    # Deterministic fallback draft
    return f"""Kính gửi: Ban Lãnh đạo Tập đoàn,

Tôi xin trân trọng báo cáo kết quả đối soát và xử lý dữ liệu định kỳ đối với chuyên đề: "{job.get('problem_statement', '')}".

Sau khi ứng dụng hệ thống AI DataIQ kiểm toán dữ liệu và làm sạch tự động, nhóm phân tích xin tóm lược các con số chính:
1. Doanh thu thực tế sau chuẩn hóa đạt: {kpis.get('adjusted_revenue', 0):,.0f} đ (đã tách riêng khoản sai lệch {kpis.get('outlier_distortion_amount', 0):,.0f} đ do giao dịch ngoại lai).
2. Phát hiện {kpis.get('total_findings_count', 0)} rủi ro nghiệp vụ trọng yếu (đã đính kèm bằng chứng chi tiết đến từng dòng chứng từ).
3. Đề xuất Ban Lãnh đạo chỉ đạo:
   - Áp dụng file dữ liệu sạch đính kèm cho báo cáo tài chính chính thức.
   - Kiểm tra hạn mức công nợ các đại lý quá hạn.
   - Khóa trường nhập tay thành tiền trên phần mềm bán lẻ.

Trân trọng kính báo!
{user_name} - Chuyên viên Phân tích Dữ liệu"""
