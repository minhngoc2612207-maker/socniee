"""
Routes for remaining sitemap modules (stubs connected to database seed data).
Ensures zero 404 errors across all 24 sitemap pages.
"""
from flask import Blueprint, render_template, redirect
from crm.auth import login_required
from crm.database import query_db
from crm.config import ENABLE_LEGACY_CRM

stub_bp = Blueprint("stubs", __name__)


@stub_bp.before_request
def guard_legacy_stubs():
    if not ENABLE_LEGACY_CRM:
        return redirect("/phan-tich/buoc-1")


# -------------------------------------------------------------
# NHÓM 1: BÁN HÀNG & LÀM VIỆC CỐT LÕI
# -------------------------------------------------------------
@stub_bp.route("/khach-hang")
@login_required
def customers_view():
    items = query_db("SELECT * FROM customers WHERE deleted_at IS NULL ORDER BY created_at DESC")
    return render_template(
        "shared/placeholder_page.html",
        active_page="customers",
        page_title="Quản Lý Khách Hàng (360°)",
        page_subtitle="Hồ sơ pháp lý, lịch sử tương tác, phân loại VIP/Thường và công nợ khách hàng",
        page_icon="fa-solid fa-building-user",
        roadmap_stage="Giai đoạn 2: Khách hàng + Lead",
        sample_items=items
    )


@stub_bp.route("/lead")
@login_required
def leads_view():
    items = query_db("SELECT * FROM leads WHERE deleted_at IS NULL ORDER BY lead_score DESC")
    return render_template(
        "shared/placeholder_page.html",
        active_page="leads",
        page_title="Khách Hàng Tiềm Năng (Leads)",
        page_subtitle="Thu thập lead tự động từ Website, Facebook, Zalo, chấm điểm lead & chuyển đổi",
        page_icon="fa-solid fa-bullseye",
        roadmap_stage="Giai đoạn 2: Khách hàng + Lead",
        sample_items=items
    )


@stub_bp.route("/co-hoi")
@login_required
def deals_view():
    items = query_db("SELECT * FROM deals WHERE deleted_at IS NULL ORDER BY expected_revenue DESC")
    return render_template(
        "shared/placeholder_page.html",
        active_page="pipeline",
        page_title="Cơ Hội Bán Hàng (Pipeline Kanban)",
        page_subtitle="Quản lý phễu kinh doanh đa giai đoạn: Mới → Tư vấn → Báo giá → Đàm phán → Chốt",
        page_icon="fa-solid fa-filter-dollar",
        roadmap_stage="Giai đoạn 3: Pipeline Kanban + Tasks",
        sample_items=items
    )


@stub_bp.route("/kanban")
@login_required
def kanban_view():
    items = query_db("SELECT * FROM kanban_cards WHERE deleted_at IS NULL ORDER BY order_index")
    return render_template(
        "shared/placeholder_page.html",
        active_page="kanban",
        page_title="Bảng Kanban Công Việc Nhóm",
        page_subtitle="Điều phối công việc Agile: Cần làm → Đang làm → Chờ duyệt → Hoàn thành",
        page_icon="fa-solid fa-table-columns",
        roadmap_stage="Giai đoạn 3: Pipeline Kanban + Tasks",
        sample_items=items
    )


@stub_bp.route("/cong-viec")
@login_required
def tasks_view():
    items = query_db("SELECT * FROM kanban_cards WHERE deleted_at IS NULL ORDER BY due_date")
    return render_template(
        "shared/placeholder_page.html",
        active_page="tasks",
        page_title="Danh Sách Công Việc",
        page_subtitle="Theo dõi tiến độ, phân công thực hiện, nhắc hạn chót liên thông với thẻ Kanban",
        page_icon="fa-solid fa-list-check",
        roadmap_stage="Giai đoạn 3: Pipeline Kanban + Tasks",
        sample_items=items
    )


@stub_bp.route("/lich")
@login_required
def calendar_view():
    return render_template(
        "shared/placeholder_page.html",
        active_page="calendar",
        page_title="Lịch Làm Việc & Cuộc Hẹn",
        page_subtitle="Lịch hẹn gặp khách hàng, cuộc gọi tư vấn, deadline hợp đồng theo tuần/tháng",
        page_icon="fa-regular fa-calendar-days",
        roadmap_stage="Giai đoạn 3: Pipeline Kanban + Tasks",
        sample_items=[]
    )


@stub_bp.route("/bao-gia")
@login_required
def quotes_view():
    return render_template(
        "shared/placeholder_page.html",
        active_page="quotes",
        page_title="Quản Lý Báo Giá",
        page_subtitle="Tạo báo giá chuyên nghiệp từ danh mục sản phẩm, tính chiết khấu thuế & xuất PDF",
        page_icon="fa-solid fa-file-invoice-dollar",
        roadmap_stage="Giai đoạn 4: Sản phẩm + Báo giá + Đơn hàng",
        sample_items=[]
    )


@stub_bp.route("/don-hang")
@login_required
def orders_view():
    return render_template(
        "shared/placeholder_page.html",
        active_page="orders",
        page_title="Quản Lý Đơn Hàng",
        page_subtitle="Xác nhận đơn, theo dõi giao nhận, thanh toán từng đợt và xuất hóa đơn",
        page_icon="fa-solid fa-cart-shopping",
        roadmap_stage="Giai đoạn 4: Sản phẩm + Báo giá + Đơn hàng",
        sample_items=[]
    )


@stub_bp.route("/san-pham")
@login_required
def products_view():
    return render_template(
        "shared/placeholder_page.html",
        active_page="products",
        page_title="Sản Phẩm & Dịch Vụ",
        page_subtitle="Danh mục hàng hóa, quản lý mã SKU, đơn giá, bảng giá đại lý và tồn kho",
        page_icon="fa-solid fa-boxes-stacked",
        roadmap_stage="Giai đoạn 4: Sản phẩm + Báo giá + Đơn hàng",
        sample_items=[]
    )


@stub_bp.route("/kho")
@login_required
def inventory_view():
    return render_template(
        "shared/placeholder_page.html",
        active_page="inventory",
        page_title="Quản Lý Xuất Nhập Tồn Kho",
        page_subtitle="Kiểm kê kho hàng, phiếu nhập/xuất kho và cảnh báo tự động khi sắp hết hàng",
        page_icon="fa-solid fa-warehouse",
        roadmap_stage="Giai đoạn 6: Hợp đồng, Tài chính, Kho, Nhân sự",
        sample_items=[]
    )


@stub_bp.route("/du-an")
@login_required
def projects_view():
    return render_template(
        "shared/placeholder_page.html",
        active_page="projects",
        page_title="Quản Lý Dự Án & Tiến Độ",
        page_subtitle="Theo dõi tiến độ dự án, các mốc thời gian (milestones) và phân bổ nguồn lực",
        page_icon="fa-solid fa-diagram-project",
        roadmap_stage="Giai đoạn 6: Hợp đồng, Tài chính, Kho, Nhân sự",
        sample_items=[]
    )


# -------------------------------------------------------------
# NHÓM 2: DOANH NGHIỆP, TÀI CHÍNH & HỢP ĐỒNG
# -------------------------------------------------------------
@stub_bp.route("/nhan-su")
@login_required
def hr_view():
    users = query_db("SELECT * FROM users WHERE deleted_at IS NULL")
    return render_template(
        "shared/placeholder_page.html",
        active_page="hr",
        page_title="Nhân Sự & Chấm Công",
        page_subtitle="Hồ sơ nhân sự, phòng ban, bảng chấm công, phê duyệt nghỉ phép và đánh giá KPI",
        page_icon="fa-solid fa-users-gear",
        roadmap_stage="Giai đoạn 6: Hợp đồng, Tài chính, Kho, Nhân sự",
        sample_items=users
    )


@stub_bp.route("/hop-dong")
@login_required
def contracts_view():
    return render_template(
        "shared/placeholder_page.html",
        active_page="contracts",
        page_title="Quản Lý Hợp Đồng Kinh Tế",
        page_subtitle="Soạn thảo hợp đồng mẫu, lưu trữ bản scan và cảnh báo tự động trước ngày hết hạn",
        page_icon="fa-solid fa-file-contract",
        roadmap_stage="Giai đoạn 6: Hợp đồng, Tài chính, Kho, Nhân sự",
        sample_items=[]
    )


@stub_bp.route("/tai-chinh")
@login_required
def finance_view():
    return render_template(
        "shared/placeholder_page.html",
        active_page="finance",
        page_title="Tài Chính, Sổ Quỹ & Công Nợ",
        page_subtitle="Theo dõi dòng tiền thu chi, công nợ phải thu đại lý và lịch hẹn thanh toán",
        page_icon="fa-solid fa-vault",
        roadmap_stage="Giai đoạn 6: Hợp đồng, Tài chính, Kho, Nhân sự",
        sample_items=[]
    )


# -------------------------------------------------------------
# NHÓM 3: CHĂM SÓC & MARKETING
# -------------------------------------------------------------
@stub_bp.route("/ho-tro")
@login_required
def support_view():
    return render_template(
        "shared/placeholder_page.html",
        active_page="support",
        page_title="Hỗ Trợ Khách Hàng (Helpdesk & SLA)",
        page_subtitle="Tiếp nhận ticket bảo hành, xử lý khiếu nại và đo lường mức độ hài lòng khách hàng",
        page_icon="fa-solid fa-headset",
        roadmap_stage="Giai đoạn 7: Hỗ trợ, Marketing, Tích hợp",
        sample_items=[]
    )


@stub_bp.route("/marketing")
@login_required
def marketing_view():
    return render_template(
        "shared/placeholder_page.html",
        active_page="marketing",
        page_title="Marketing & Chăm Sóc Tự Động",
        page_subtitle="Kịch bản gửi Email/SMS/Zalo OA tự động chúc mừng sinh nhật, nhắc tái mua",
        page_icon="fa-solid fa-paper-plane",
        roadmap_stage="Giai đoạn 7: Hỗ trợ, Marketing, Tích hợp",
        sample_items=[]
    )


@stub_bp.route("/chien-dich")
@login_required
def campaigns_view():
    return render_template(
        "shared/placeholder_page.html",
        active_page="campaigns",
        page_title="Chiến Dịch Quảng Bá & Đo Lường ROI",
        page_subtitle="Quản lý ngân sách marketing, nguồn khách mang lại và hiệu quả doanh số",
        page_icon="fa-solid fa-bullhorn",
        roadmap_stage="Giai đoạn 7: Hỗ trợ, Marketing, Tích hợp",
        sample_items=[]
    )


@stub_bp.route("/khuyen-mai")
@login_required
def loyalty_view():
    return render_template(
        "shared/placeholder_page.html",
        active_page="loyalty",
        page_title="Khuyến Mãi & Tích Điểm Thành Viên",
        page_subtitle="Chính sách hạng thẻ (Silver, Gold, Diamond), mã giảm giá voucher cho khách VIP",
        page_icon="fa-solid fa-award",
        roadmap_stage="Giai đoạn 7: Hỗ trợ, Marketing, Tích hợp",
        sample_items=[]
    )


# -------------------------------------------------------------
# NHÓM 4: BÁO CÁO ĐA CHIỀU
# -------------------------------------------------------------
@stub_bp.route("/bao-cao")
@login_required
def reports_view():
    return render_template(
        "shared/placeholder_page.html",
        active_page="reports",
        page_title="Báo Cáo Thống Kê Đa Chiều",
        page_subtitle="Báo cáo doanh thu theo thời gian, tỷ lệ chuyển đổi sales, tồn kho và công nợ",
        page_icon="fa-solid fa-chart-line",
        roadmap_stage="Giai đoạn 5: Dashboard + Báo cáo",
        sample_items=[]
    )
