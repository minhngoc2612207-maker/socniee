"""
Authentication Routes for Soconie CRM - Lê Minh Ngọc.
ĐÃ BỎ HOÀN TOÀN RÀO CẢN ĐĂNG NHẬP, TẠO TÀI KHOẢN VÀ QUÊN MẬT KHẨU:
Người dùng được cấp quyền truy cập trực tiếp mọi tính năng với tư cách Chủ sở hữu Lê Minh Ngọc.
"""
import uuid
import secrets
import hashlib
from datetime import datetime, timedelta
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, session

from crm.database import query_db, execute_db
from crm.auth import (
    get_current_user,
    login_user,
    logout_user,
    hash_password,
    verify_password,
    log_audit
)
from crm.site_config import (
    AUTH_OTP_ENABLED,
    SYSTEM_NAME,
    OWNER_NAME,
    HOTLINE_DISPLAY,
    HOTLINE_RAW,
    EMAIL
)

auth_bp = Blueprint("auth", __name__)


@auth_bp.before_request
def guard_auth():
    from crm.config import ENABLE_LEGACY_CRM
    if not ENABLE_LEGACY_CRM:
        return redirect("/phan-tich/buoc-1")


def get_client_ip() -> str:
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.remote_addr or "127.0.0.1"


# =====================================================================
# 1. TẠO TÀI KHOẢN (REGISTER) - TRUY CẬP TRỰC TIẾP
# =====================================================================

@auth_bp.route("/api/auth/register", methods=["POST"])
@auth_bp.route("/tao-tai-khoan", methods=["GET", "POST"])
@auth_bp.route("/dang-ky", methods=["GET", "POST"])
@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    """Đã bỏ tạo tài khoản -> Tự động cấp quyền Chủ sở hữu và vào thẳng CRM."""
    user = get_current_user()
    login_user(user)
    if request.is_json:
        return jsonify({
            "success": True,
            "message": f"Chào mừng {user['full_name']} đến với Soconie CRM!",
            "user": user,
            "redirect_url": url_for("dashboard.overview")
        })
    return redirect(url_for("dashboard.overview"))


# =====================================================================
# 2. ĐĂNG NHẬP (LOGIN) - TRUY CẬP TRỰC TIẾP
# =====================================================================

@auth_bp.route("/api/auth/login", methods=["POST"])
@auth_bp.route("/dang-nhap", methods=["GET", "POST"])
@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    """Đã bỏ đăng nhập -> Tự động xác thực Chủ sở hữu Lê Minh Ngọc và vào thẳng CRM."""
    user = get_current_user()
    login_user(user)
    next_url = request.args.get("next") or request.form.get("next") or url_for("dashboard.overview")
    if request.is_json:
        return jsonify({
            "success": True,
            "message": f"Chào mừng {user['full_name']}!",
            "redirect_url": next_url
        })
    return redirect(next_url)


# =====================================================================
# 3. QUÊN MẬT KHẨU - TRUY CẬP TRỰC TIẾP
# =====================================================================

@auth_bp.route("/api/auth/forgot-password", methods=["POST"])
@auth_bp.route("/quen-mat-khau", methods=["GET", "POST"])
@auth_bp.route("/forgot-password", methods=["GET", "POST"])
def api_forgot_password():
    """Đã bỏ quên mật khẩu -> Tự động xác thực và vào thẳng CRM."""
    user = get_current_user()
    login_user(user)
    if request.is_json:
        return jsonify({
            "success": True,
            "message": "Không cần đặt lại mật khẩu! Bạn đã có toàn quyền truy cập.",
            "redirect_url": url_for("dashboard.overview")
        })
    return redirect(url_for("dashboard.overview"))


@auth_bp.route("/dat-lai-mat-khau", methods=["GET", "POST"])
def reset_password_page():
    return redirect(url_for("dashboard.overview"))


# =====================================================================
# 4. ĐĂNG XUẤT (LOGOUT)
# =====================================================================

@auth_bp.route("/dang-xuat", methods=["GET", "POST"])
@auth_bp.route("/logout", methods=["GET", "POST"])
def logout():
    session.clear()
    return redirect(url_for("dashboard.landing"))


# =====================================================================
# 5. LEGACY SMS OTP ADAPTER (DISABLED)
# =====================================================================

@auth_bp.route("/api/auth/send-otp", methods=["POST"])
def api_send_otp():
    return jsonify({
        "success": True,
        "message": "Hệ thống đã mở truy cập trực tiếp, không yêu cầu mã OTP."
    })


@auth_bp.route("/api/auth/verify-otp", methods=["POST"])
def api_verify_otp():
    return jsonify({
        "success": True,
        "message": "Xác nhận thành công."
    })
