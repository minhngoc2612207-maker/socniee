"""
Dashboard routes for Minh Soconie CRM.
"""
from flask import Blueprint, render_template, redirect, url_for
from crm.auth import login_required, get_current_user
from crm.database import query_db
from crm.config import ENABLE_LEGACY_CRM

dashboard_bp = Blueprint("dashboard", __name__)


@dashboard_bp.route("/")
def welcome_home():
    """Renders Screen 1: Welcome modal showcase for Soconie CRM - Lê Minh Ngọc."""
    return render_template("welcome.html")


@dashboard_bp.route("/trang-chu")
def landing_home():
    """Renders Screen 2: Main Silk landing page for Soconie CRM - Lê Minh Ngọc."""
    return render_template("landing.html")


@dashboard_bp.route("/studio")
def studio_redirect():
    """Redirects to Step 1 of Analysis Studio."""
    return redirect("/phan-tich/buoc-1")



@dashboard_bp.route("/tong-quan-3d")
def business_3d_showcase():
    """Renders the futuristic 3D Glassmorphic Business Overview (Sales Funnel, Real-time KPIs, AI Assistant)."""
    if not ENABLE_LEGACY_CRM:
        return redirect("/phan-tich/buoc-1")
    return render_template("dashboard/showcase_3d.html")


@dashboard_bp.route("/crm")
def crm_root():
    if not ENABLE_LEGACY_CRM:
        return redirect("/phan-tich/buoc-1")
    user = get_current_user()
    if user:
        return redirect(url_for("dashboard.overview"))
    return redirect("/phan-tich/buoc-1")


@dashboard_bp.route("/tong-quan")
@login_required
def overview():
    if not ENABLE_LEGACY_CRM:
        return redirect("/phan-tich/buoc-1")
    # Compute dynamic stats
    cust_count = query_db("SELECT COUNT(*) as cnt FROM customers WHERE deleted_at IS NULL", one=True)["cnt"]
    leads_count = query_db("SELECT COUNT(*) as cnt FROM leads WHERE deleted_at IS NULL", one=True)["cnt"]
    deals_count = query_db("SELECT COUNT(*) as cnt FROM deals WHERE deleted_at IS NULL", one=True)["cnt"]
    cards_count = query_db("SELECT COUNT(*) as cnt FROM kanban_cards WHERE deleted_at IS NULL", one=True)["cnt"]

    stats = {
        "total_customers": cust_count,
        "total_leads": leads_count,
        "total_deals": deals_count,
        "total_cards": cards_count
    }

    # Urgent kanban tasks
    kanban_cards = query_db("""
        SELECT * FROM kanban_cards 
        WHERE deleted_at IS NULL 
        ORDER BY CASE priority WHEN 'KHAN_CAP' THEN 1 WHEN 'CAO' THEN 2 ELSE 3 END 
        LIMIT 5
    """)

    # Recent customers
    recent_customers = query_db("""
        SELECT * FROM customers 
        WHERE deleted_at IS NULL 
        ORDER BY created_at DESC 
        LIMIT 5
    """)

    return render_template(
        "dashboard/overview.html",
        active_page="dashboard",
        stats=stats,
        kanban_cards=kanban_cards,
        recent_customers=recent_customers
    )
