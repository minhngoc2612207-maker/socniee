"""
OTP Service Layer for Soconie CRM.
Handles cryptographic OTP generation, HMAC-SHA256 hashing, rate limiting, and verification.
"""
import re
import hmac
import hashlib
import secrets
from datetime import datetime, timedelta
from typing import Tuple, Dict, Any, Optional

from crm.database import query_db, execute_db
from crm.sms.provider import get_sms_provider
from crm.site_config import (
    OTP_LENGTH,
    OTP_TTL_SECONDS,
    OTP_RESEND_COOLDOWN_SECONDS,
    OTP_MAX_ATTEMPTS,
    OTP_LOCK_MINUTES,
    OTP_DAILY_LIMIT_PER_PHONE,
    OTP_DAILY_LIMIT_PER_IP,
    OTP_PEPPER,
    OTP_DEV_ECHO
)

# Valid Vietnamese mobile prefixes: 03x, 05x, 07x, 08x, 09x
VN_MOBILE_PREFIX_REGEX = re.compile(r"^(?:\+84|84|0)(3[2-9]|5[2689]|7[06-9]|8[1-9]|9[0-9])([0-9]{7})$")


def normalize_vietnam_phone(raw_phone: str) -> Optional[str]:
    """
    Normalizes any Vietnamese phone format to standard E.164 (+84xxxxxxxxx).
    Returns None if invalid mobile number.
    Examples:
      '0363651407'    -> '+84363651407'
      '0363 651 407'  -> '+84363651407'
      '+84363651407'  -> '+84363651407'
      '84363651407'   -> '+84363651407'
    """
    if not raw_phone:
        return None
    cleaned = re.sub(r"[\s\-\.\(\)]", "", str(raw_phone).strip())
    match = VN_MOBILE_PREFIX_REGEX.match(cleaned)
    if not match:
        return None
    prefix, suffix = match.groups()
    return f"+84{prefix}{suffix}"


def format_vietnam_phone_display(phone_e164: str) -> str:
    """Formats '+84363651407' to '0363 651 407'."""
    if not phone_e164:
        return ""
    digits = phone_e164.replace("+84", "0") if phone_e164.startswith("+84") else phone_e164
    if len(digits) == 10:
        return f"{digits[:4]} {digits[4:7]} {digits[7:]}"
    return digits


def mask_phone(phone: str) -> str:
    """Masks phone number: '0363 651 407' -> '036****407'."""
    display = format_vietnam_phone_display(phone).replace(" ", "")
    if len(display) >= 10:
        return f"{display[:3]}****{display[-3:]}"
    return display


def _hash_otp(code: str) -> str:
    """Computes HMAC-SHA256 hash of raw OTP code with secret OTP_PEPPER."""
    return hmac.new(OTP_PEPPER.encode("utf-8"), code.encode("utf-8"), hashlib.sha256).hexdigest()


def generate_secure_otp(length: int = OTP_LENGTH) -> str:
    """Cryptographically secure numeric OTP generator."""
    # e.g., 6 digits from 000000 to 999999
    max_val = 10 ** length
    num = secrets.randbelow(max_val)
    return str(num).zfill(length)


def request_otp(raw_phone: str, purpose: str = "register", ip_address: str = "127.0.0.1") -> Dict[str, Any]:
    """
    Validates limits and generates + sends real OTP SMS.
    Returns: { success: bool, message: str, cooldown_seconds: int, masked_phone: str, dev_code: Optional[str] }
    """
    phone_e164 = normalize_vietnam_phone(raw_phone)
    if not phone_e164:
        return {
            "success": False,
            "message": "Số điện thoại không hợp lệ. Vui lòng nhập số di động Việt Nam (10 số).",
            "cooldown_seconds": 0
        }

    now = datetime.now()
    now_str = now.strftime("%Y-%m-%d %H:%M:%S")
    today_start = now.strftime("%Y-%m-%d 00:00:00")

    # 1. Check if phone is temporarily locked due to failed attempts
    lock_record = query_db("""
        SELECT locked_until FROM otp_locks
        WHERE phone = ? AND locked_until > ?
        LIMIT 1
    """, (phone_e164, now_str), one=True)
    if lock_record:
        locked_until_dt = datetime.strptime(lock_record["locked_until"], "%Y-%m-%d %H:%M:%S")
        mins_left = max(1, int((locked_until_dt - now).total_seconds() / 60))
        return {
            "success": False,
            "message": f"Số điện thoại này đang bị khóa tạm thời do nhập sai nhiều lần. Vui lòng thử lại sau {mins_left} phút.",
            "cooldown_seconds": mins_left * 60
        }

    # 2. Daily limit per phone
    phone_today_count = query_db("""
        SELECT COUNT(*) as cnt FROM otp_verifications
        WHERE phone = ? AND created_at >= ?
    """, (phone_e164, today_start), one=True)["cnt"]
    if phone_today_count >= OTP_DAILY_LIMIT_PER_PHONE:
        return {
            "success": False,
            "message": "Bạn đã vượt quá giới hạn gửi mã OTP trong ngày (tối đa 5 lần/ngày). Vui lòng thử lại vào ngày mai.",
            "cooldown_seconds": 0
        }

    # 3. Daily limit per IP
    ip_today_count = query_db("""
        SELECT COUNT(*) as cnt FROM otp_verifications
        WHERE ip_address = ? AND created_at >= ?
    """, (ip_address, today_start), one=True)["cnt"]
    if ip_today_count >= OTP_DAILY_LIMIT_PER_IP:
        return {
            "success": False,
            "message": "Địa chỉ mạng của bạn đã gửi quá nhiều yêu cầu trong ngày. Vui lòng thử lại sau.",
            "cooldown_seconds": 0
        }

    # 4. Check 60-second cooldown from last sent OTP
    last_otp = query_db("""
        SELECT created_at FROM otp_verifications
        WHERE phone = ? AND purpose = ?
        ORDER BY created_at DESC LIMIT 1
    """, (phone_e164, purpose), one=True)
    if last_otp:
        last_dt = datetime.strptime(last_otp["created_at"], "%Y-%m-%d %H:%M:%S")
        elapsed = (now - last_dt).total_seconds()
        if elapsed < OTP_RESEND_COOLDOWN_SECONDS:
            wait_time = int(OTP_RESEND_COOLDOWN_SECONDS - elapsed)
            return {
                "success": False,
                "message": f"Vui lòng đợi {wait_time} giây trước khi yêu cầu gửi lại mã mới.",
                "cooldown_seconds": wait_time
            }

    # 5. Invalidate previous active OTPs for this phone & purpose
    execute_db("""
        UPDATE otp_verifications
        SET is_used = 1
        WHERE phone = ? AND purpose = ? AND is_used = 0
    """, (phone_e164, purpose))

    # 6. Generate cryptographically safe OTP and calculate expiration
    code = generate_secure_otp(OTP_LENGTH)
    code_hash = _hash_otp(code)
    expires_at = (now + timedelta(seconds=OTP_TTL_SECONDS)).strftime("%Y-%m-%d %H:%M:%S")

    # 7. Store in database
    execute_db("""
        INSERT INTO otp_verifications (phone, code_hash, purpose, ip_address, attempts, max_attempts, is_used, expires_at, created_at)
        VALUES (?, ?, ?, ?, 0, ?, 0, ?, ?)
    """, (phone_e164, code_hash, purpose, ip_address, OTP_MAX_ATTEMPTS, expires_at, now_str))

    # 8. Send SMS via configured adapter
    sms_provider = get_sms_provider()
    sms_result = sms_provider.send_otp(phone_e164, code, purpose)

    return {
        "success": True,
        "message": f"Mã xác minh gồm 6 số đã được gửi qua tin nhắn SMS tới {mask_phone(phone_e164)}.",
        "cooldown_seconds": OTP_RESEND_COOLDOWN_SECONDS,
        "masked_phone": mask_phone(phone_e164),
        "dev_code": code if OTP_DEV_ECHO else None
    }


def verify_otp(raw_phone: str, user_code: str, purpose: str = "register") -> Dict[str, Any]:
    """
    Verifies user-submitted OTP code.
    Returns: { success: bool, message: str, phone_e164: str, locked: bool }
    """
    phone_e164 = normalize_vietnam_phone(raw_phone)
    if not phone_e164:
        return {"success": False, "message": "Số điện thoại không hợp lệ.", "phone_e164": ""}

    cleaned_code = re.sub(r"\D", "", str(user_code or "").strip())
    if len(cleaned_code) != OTP_LENGTH:
        return {"success": False, "message": f"Mã OTP phải gồm đủ {OTP_LENGTH} chữ số.", "phone_e164": phone_e164}

    now = datetime.now()
    now_str = now.strftime("%Y-%m-%d %H:%M:%S")

    # 1. Check temporary lock
    lock = query_db("""
        SELECT locked_until FROM otp_locks
        WHERE phone = ? AND locked_until > ?
        LIMIT 1
    """, (phone_e164, now_str), one=True)
    if lock:
        return {
            "success": False,
            "message": "Số điện thoại này đang bị khóa tạm thời do nhập sai quá 5 lần. Vui lòng thử lại sau 15 phút.",
            "phone_e164": phone_e164,
            "locked": True
        }

    # 2. Get latest active OTP record
    record = query_db("""
        SELECT id, code_hash, attempts, max_attempts, expires_at
        FROM otp_verifications
        WHERE phone = ? AND purpose = ? AND is_used = 0
        ORDER BY created_at DESC LIMIT 1
    """, (phone_e164, purpose), one=True)

    if not record:
        return {
            "success": False,
            "message": "Không tìm thấy mã OTP nào đang chờ xác nhận hoặc mã đã hết hạn. Vui lòng bấm 'Gửi lại mã'.",
            "phone_e164": phone_e164
        }

    # 3. Check expiration
    if record["expires_at"] < now_str:
        execute_db("UPDATE otp_verifications SET is_used = 1 WHERE id = ?", (record["id"],))
        return {
            "success": False,
            "message": "Mã xác minh này đã hết hạn (quá 5 phút). Vui lòng yêu cầu mã mới.",
            "phone_e164": phone_e164
        }

    # 4. Constant-time hash comparison
    expected_hash = record["code_hash"]
    computed_hash = _hash_otp(cleaned_code)

    if not hmac.compare_digest(expected_hash, computed_hash):
        new_attempts = record["attempts"] + 1
        execute_db("UPDATE otp_verifications SET attempts = ? WHERE id = ?", (new_attempts, record["id"]))
        
        remaining = record["max_attempts"] - new_attempts
        if remaining <= 0:
            # Lock phone for OTP_LOCK_MINUTES
            lock_until = (now + timedelta(minutes=OTP_LOCK_MINUTES)).strftime("%Y-%m-%d %H:%M:%S")
            execute_db("""
                INSERT OR REPLACE INTO otp_locks (phone, locked_until, reason, created_at)
                VALUES (?, ?, 'Sai mã OTP quá 5 lần', ?)
            """, (phone_e164, lock_until, now_str))
            return {
                "success": False,
                "message": f"Bạn đã nhập sai mã 5 lần. Tài khoản bị tạm khóa trong {OTP_LOCK_MINUTES} phút.",
                "phone_e164": phone_e164,
                "locked": True
            }

        return {
            "success": False,
            "message": f"Mã xác minh không chính xác. Bạn còn {remaining} lần thử.",
            "phone_e164": phone_e164,
            "remaining_attempts": remaining
        }

    # 5. Success: mark used
    execute_db("UPDATE otp_verifications SET is_used = 1 WHERE id = ?", (record["id"],))
    return {
        "success": True,
        "message": "Xác minh mã OTP thành công!",
        "phone_e164": phone_e164
    }
