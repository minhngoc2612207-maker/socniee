"""
Analysis Engine Service for Soconie CRM - Không Gian Phân Tích Dữ Liệu
Handles data ingestion (Google Sheets, CSV, Excel, CRM SQLite), data profiling,
cleaning rules, grounded AI insight generation, Pareto/Funnel metrics, and exports.
"""
import os
import re
import io
import json
import math
import uuid
import datetime
import requests
import pandas as pd
from typing import Dict, Any, List, Optional, Tuple

from crm.site_config import (
    SYSTEM_NAME,
    OWNER_NAME,
    ANALYSIS_MAX_FILE_SIZE_MB,
    GEMINI_API_KEY,
    AI_PROVIDER
)
from crm.database import query_db, execute_db


# =====================================================================
# 1. BỘ DỮ LIỆU MẪU DOANH THU & MARKETING CRM (2026)
# =====================================================================
SAMPLE_CRM_DATASET = [
    {"Ma_KH": "KH-1001", "Ho_Ten": "  Nguyễn Văn An ", "So_Dien_Thoai": "0912345678", "Email": "an.nguyen@gmail.com", "Tinh_Thanh": "Hà Nội", "Nguon_Lead": "Facebook Ads", "Giai_Doan": "Đã chốt", "Doanh_Thu": 45000000, "Ngay_Tao": "2026-01-05", "Nhan_Vien": "Trần Thị Mai Phương", "Trang_Thai": "VIP"},
    {"Ma_KH": "KH-1002", "Ho_Ten": "Trần Thị Bích", "So_Dien_Thoai": "84988776655", "Email": "bich.tran@yahoo.com", "Tinh_Thanh": "TP. Hồ Chí Minh", "Nguon_Lead": "Google Search", "Giai_Doan": "Đã chốt", "Doanh_Thu": 68000000, "Ngay_Tao": "2026-01-07", "Nhan_Vien": "Lê Văn Hùng", "Trang_Thai": "VIP"},
    {"Ma_KH": "KH-1003", "Ho_Ten": "Lê Hoàng Long", "So_Dien_Thoai": "0903112233", "Email": "long.le@anphat.vn", "Tinh_Thanh": "Đà Nẵng", "Nguon_Lead": "Giới thiệu", "Giai_Doan": "Báo giá", "Doanh_Thu": 24000000, "Ngay_Tao": "2026-01-12", "Nhan_Vien": "Trần Thị Mai Phương", "Trang_Thai": "Chờ phản hồi"},
    {"Ma_KH": "KH-1004", "Ho_Ten": "Phạm Minh Đức", "So_Dien_Thoai": "0977889900", "Email": "", "Tinh_Thanh": "Hải Phòng", "Nguon_Lead": "Website", "Giai_Doan": "Đang tư vấn", "Doanh_Thu": 15000000, "Ngay_Tao": "2026-01-15", "Nhan_Vien": "Lê Văn Hùng", "Trang_Thai": "Cần gọi lại"},
    {"Ma_KH": "KH-1005", "Ho_Ten": "Vũ Thu Hà", "So_Dien_Thoai": "+84945678901", "Email": "ha.vu@gmail.com", "Tinh_Thanh": "Hà Nội", "Nguon_Lead": "Facebook Ads", "Giai_Doan": "Đã chốt", "Doanh_Thu": 52000000, "Ngay_Tao": "2026-01-18", "Nhan_Vien": "Nguyễn Hoàng Nam", "Trang_Thai": "VIP"},
    {"Ma_KH": "KH-1006", "Ho_Ten": "Hoàng Tuấn Kiệt", "So_Dien_Thoai": "0934567890", "Email": "kiet.hoang@techvina.com", "Tinh_Thanh": "Bình Dương", "Nguon_Lead": "Google Search", "Giai_Doan": "Mới", "Doanh_Thu": 18000000, "Ngay_Tao": "2026-01-20", "Nhan_Vien": "Nguyễn Hoàng Nam", "Trang_Thai": "Chưa liên hệ"},
    {"Ma_KH": "KH-1007", "Ho_Ten": "Đỗ Mỹ Linh", "So_Dien_Thoai": "0989001122", "Email": "linh.do@fashion.vn", "Tinh_Thanh": "TP. Hồ Chí Minh", "Nguon_Lead": "Facebook Ads", "Giai_Doan": "Đã chốt", "Doanh_Thu": 85000000, "Ngay_Tao": "2026-01-22", "Nhan_Vien": "Trần Thị Mai Phương", "Trang_Thai": "VIP"},
    {"Ma_KH": "KH-1008", "Ho_Ten": "Ngô Quốc Bảo", "So_Dien_Thoai": "0918765432", "Email": "bao.ngo@saigonlog.com", "Tinh_Thanh": "Cần Thơ", "Nguon_Lead": "Giới thiệu", "Giai_Doan": "Đang tư vấn", "Doanh_Thu": 30000000, "Ngay_Tao": "2026-01-25", "Nhan_Vien": "Lê Văn Hùng", "Trang_Thai": "Đang gửi hồ sơ"},
    {"Ma_KH": "KH-1009", "Ho_Ten": "Bùi Lan Anh", "So_Dien_Thoai": "0966554433", "Email": "lananh.bui@gmail.com", "Tinh_Thanh": "Hà Nội", "Nguon_Lead": "Website", "Giai_Doan": "Báo giá", "Doanh_Thu": 22000000, "Ngay_Tao": "2026-01-28", "Nhan_Vien": "Nguyễn Hoàng Nam", "Trang_Thai": "Đã gửi báo giá"},
    {"Ma_KH": "KH-1010", "Ho_Ten": "Đinh Công Thành", "So_Dien_Thoai": "0909123456", "Email": "thanh.dinh@thanhcorp.vn", "Tinh_Thanh": "Đà Nẵng", "Nguon_Lead": "Google Search", "Giai_Doan": "Đã chốt", "Doanh_Thu": 110000000, "Ngay_Tao": "2026-02-02", "Nhan_Vien": "Trần Thị Mai Phương", "Trang_Thai": "VIP"},
    {"Ma_KH": "KH-1011", "Ho_Ten": "Trịnh Kim Ngân", "So_Dien_Thoai": "0933221100", "Email": "ngan.trinh@gmail.com", "Tinh_Thanh": "Hải Phòng", "Nguon_Lead": "Facebook Ads", "Giai_Doan": "Hủy", "Doanh_Thu": 12000000, "Ngay_Tao": "2026-02-04", "Nhan_Vien": "Lê Văn Hùng", "Trang_Thai": "Không phù hợp"},
    {"Ma_KH": "KH-1012", "Ho_Ten": "Dương Thanh Tùng", "So_Dien_Thoai": "0971234888", "Email": "tung.duong@viettech.vn", "Tinh_Thanh": "TP. Hồ Chí Minh", "Nguon_Lead": "Giới thiệu", "Giai_Doan": "Đã chốt", "Doanh_Thu": 95000000, "Ngay_Tao": "2026-02-06", "Nhan_Vien": "Trần Thị Mai Phương", "Trang_Thai": "VIP"},
    {"Ma_KH": "KH-1013", "Ho_Ten": "Lý Quí Trung", "So_Dien_Thoai": "0984112233", "Email": "trung.ly@fnb.com.vn", "Tinh_Thanh": "Hà Nội", "Nguon_Lead": "Website", "Giai_Doan": "Đang tư vấn", "Doanh_Thu": 28000000, "Ngay_Tao": "2026-02-09", "Nhan_Vien": "Nguyễn Hoàng Nam", "Trang_Thai": "Chờ demo"},
    {"Ma_KH": "KH-1014", "Ho_Ten": "Võ Thị Sáu", "So_Dien_Thoai": "0915667788", "Email": "sau.vo@logistic.com", "Tinh_Thanh": "Vũng Tàu", "Nguon_Lead": "Google Search", "Giai_Doan": "Đã chốt", "Doanh_Thu": 40000000, "Ngay_Tao": "2026-02-12", "Nhan_Vien": "Lê Văn Hùng", "Trang_Thai": "VIP"},
    {"Ma_KH": "KH-1015", "Ho_Ten": "Lê Quang Khải", "So_Dien_Thoai": "0942334455", "Email": "", "Tinh_Thanh": "Đà Nẵng", "Nguon_Lead": "Facebook Ads", "Giai_Doan": "Mới", "Doanh_Thu": 16000000, "Ngay_Tao": "2026-02-15", "Nhan_Vien": "Nguyễn Hoàng Nam", "Trang_Thai": "Chưa gọi"},
    # Duplicate rows for cleaning demonstration
    {"Ma_KH": "KH-1001", "Ho_Ten": "  Nguyễn Văn An ", "So_Dien_Thoai": "0912345678", "Email": "an.nguyen@gmail.com", "Tinh_Thanh": "Hà Nội", "Nguon_Lead": "Facebook Ads", "Giai_Doan": "Đã chốt", "Doanh_Thu": 45000000, "Ngay_Tao": "2026-01-05", "Nhan_Vien": "Trần Thị Mai Phương", "Trang_Thai": "VIP"},
    {"Ma_KH": "KH-1002", "Ho_Ten": "Trần Thị Bích", "So_Dien_Thoai": "84988776655", "Email": "bich.tran@yahoo.com", "Tinh_Thanh": "TP. Hồ Chí Minh", "Nguon_Lead": "Google Search", "Giai_Doan": "Đã chốt", "Doanh_Thu": 68000000, "Ngay_Tao": "2026-01-07", "Nhan_Vien": "Lê Văn Hùng", "Trang_Thai": "VIP"},
]


# =====================================================================
# 2. XỬ LÝ & NẠP NGUỒN DỮ LIỆU (BƯỚC 1)
# =====================================================================

def get_sample_dataset() -> Dict[str, Any]:
    """Returns sample CRM dataset for instant exploration."""
    df = pd.DataFrame(SAMPLE_CRM_DATASET)
    return profile_dataframe(df, source_name="CRM_Kinh_Doanh_Mau_2026.csv")


def get_crm_internal_dataset() -> Dict[str, Any]:
    """Extracts real live data from SQLite CRM tables."""
    query = """
        SELECT 
            c.id as Ma_KH,
            c.name as Ho_Ten,
            c.phone as So_Dien_Thoai,
            c.email as Email,
            c.city as Tinh_Thanh,
            c.source as Nguon_Lead,
            COALESCE(d.stage, 'Chưa có cơ hội') as Giai_Doan,
            COALESCE(d.expected_revenue, 0) as Doanh_Thu,
            SUBSTR(c.created_at, 1, 10) as Ngay_Tao,
            COALESCE(u.full_name, 'Chưa gán') as Nhan_Vien,
            c.type as Trang_Thai
        FROM customers c
        LEFT JOIN deals d ON d.customer_id = c.id AND d.deleted_at IS NULL
        LEFT JOIN users u ON u.id = c.assigned_to
        WHERE c.deleted_at IS NULL
        ORDER BY c.created_at DESC
        LIMIT 200
    """
    rows = query_db(query)
    if not rows:
        return get_sample_dataset()
    
    clean_rows = []
    for r in rows:
        clean_rows.append(dict(r))
    df = pd.DataFrame(clean_rows)
    return profile_dataframe(df, source_name="Soconie_CRM_Internal_Data")


def parse_google_sheets_url(url: str) -> Dict[str, Any]:
    """
    Extracts spreadsheet ID and fetches CSV export from Google Sheets.
    Supports both direct sheet URLs and public sharing links.
    """
    url = url.strip()
    match = re.search(r"/spreadsheets/d/([a-zA-Z0-9-_]+)", url)
    if not match:
        raise ValueError("Liên kết Google Sheets không hợp lệ! Vui lòng kiểm tra định dạng https://docs.google.com/spreadsheets/d/ID/...")

    sheet_id = match.group(1)
    
    # Check gid if specified
    gid_match = re.search(r"[#&]gid=([0-9]+)", url)
    gid = gid_match.group(1) if gid_match else "0"

    export_url = f"https://docs.google.com/spreadsheets/d/{sheet_id}/export?format=csv&gid={gid}"
    try:
        res = requests.get(export_url, timeout=12)
        if res.status_code == 404:
            raise ValueError("Không tìm thấy bảng tính Google Sheets! Hãy kiểm tra lại ID bảng tính.")
        elif res.status_code == 401 or res.status_code == 403 or "accounts.google.com" in res.url:
            raise ValueError("Bảng tính chưa được cấp quyền xem! Vui lòng chọn 'Chia sẻ' -> 'Bất kỳ ai có đường liên kết' có quyền Xem.")
        elif res.status_code != 200:
            raise ValueError(f"Không thể kết nối Google Sheets (Mã phản hồi: {res.status_code}).")

        # Parse CSV content
        content = res.content.decode("utf-8-sig", errors="replace")
        df = pd.read_csv(io.StringIO(content))
        if df.empty or len(df.columns) == 0:
            raise ValueError("Bảng tính Google Sheets được chia sẻ nhưng không có dữ liệu hoặc hàng tiêu đề rỗng.")

        return profile_dataframe(df, source_name=f"Google_Sheet_{sheet_id[:8]}.csv")
    except requests.exceptions.RequestException as e:
        raise ValueError(f"Lỗi kết nối mạng khi tải Google Sheets: {str(e)}")


def parse_uploaded_file(file_storage) -> Dict[str, Any]:
    """Parses uploaded .csv, .tsv, .xlsx, .xls file."""
    filename = file_storage.filename or "upload.csv"
    ext = os.path.splitext(filename)[1].lower()
    
    # Validate extension
    if ext not in [".csv", ".tsv", ".xlsx", ".xls"]:
        raise ValueError("Định dạng tệp không được hỗ trợ! Vui lòng tải tệp .csv, .tsv hoặc .xlsx.")

    file_bytes = file_storage.read()
    if len(file_bytes) > ANALYSIS_MAX_FILE_SIZE_MB * 1024 * 1024:
        raise ValueError(f"Dung lượng tệp vượt quá giới hạn cho phép ({ANALYSIS_MAX_FILE_SIZE_MB} MB).")

    if len(file_bytes) == 0:
        raise ValueError("Tệp tải lên hoàn toàn rỗng!")

    try:
        if ext == ".csv":
            df = pd.read_csv(io.BytesIO(file_bytes), encoding="utf-8-sig")
        elif ext == ".tsv":
            df = pd.read_csv(io.BytesIO(file_bytes), sep="\t", encoding="utf-8-sig")
        else:
            df = pd.read_excel(io.BytesIO(file_bytes))
    except Exception as e:
        # Fallback encoding try
        try:
            if ext in [".csv", ".tsv"]:
                df = pd.read_csv(io.BytesIO(file_bytes), encoding="latin1")
            else:
                raise e
        except Exception:
            raise ValueError(f"Không thể đọc nội dung tệp ({ext}). Tệp có thể bị hỏng hoặc mã hóa không hợp lệ: {str(e)}")

    if df.empty or len(df.columns) == 0:
        raise ValueError("Tệp đã tải lên không chứa hàng dữ liệu hoặc cột hợp lệ.")

    return profile_dataframe(df, source_name=filename)


def infer_column_types(df: pd.DataFrame) -> Dict[str, str]:
    """Infers friendly Vietnamese column data types."""
    types = {}
    for col in df.columns:
        s = df[col].dropna()
        if s.empty:
            types[col] = "Văn bản"
            continue
        
        col_lower = str(col).lower()
        if "phone" in col_lower or "thoai" in col_lower or "sdt" in col_lower:
            types[col] = "Số điện thoại"
            continue
        if "mail" in col_lower:
            types[col] = "Email"
            continue
        if "ngay" in col_lower or "date" in col_lower or "time" in col_lower:
            types[col] = "Ngày tháng"
            continue
            
        if pd.api.types.is_numeric_dtype(s):
            types[col] = "Số / Tiền tệ"
        elif pd.api.types.is_datetime64_any_dtype(s):
            types[col] = "Ngày tháng"
        elif pd.api.types.is_bool_dtype(s):
            types[col] = "Đúng/Sai"
        else:
            # Check string patterns
            first_val = str(s.iloc[0]).strip()
            if re.match(r"^(\+84|0)\d{9,10}$", first_val):
                types[col] = "Số điện thoại"
            elif "@" in first_val and "." in first_val:
                types[col] = "Email"
            else:
                types[col] = "Văn bản"
    return types


def profile_dataframe(df: pd.DataFrame, source_name: str = "dataset.csv") -> Dict[str, Any]:
    """Generates complete profiling metadata, preview rows, and column analysis."""
    # Replace NaN with empty string for JSON serialization
    df_clean = df.copy()
    
    total_rows = len(df_clean)
    total_cols = len(df_clean.columns)
    
    col_types = infer_column_types(df_clean)
    columns_info = []
    
    for col in df_clean.columns:
        s = df_clean[col]
        missing_count = int(s.isna().sum()) + int((s == "").sum()) if s.dtype == object else int(s.isna().sum())
        columns_info.append({
            "name": str(col),
            "type": col_types.get(col, "Văn bản"),
            "missing_count": missing_count,
            "missing_pct": round(missing_count / total_rows * 100, 1) if total_rows > 0 else 0
        })

    # Prepare preview rows (max 20 rows)
    preview_df = df_clean.head(20).fillna("")
    preview_rows = preview_df.to_dict(orient="records")

    # Safe full data array for in-memory session processing
    all_rows = df_clean.fillna("").to_dict(orient="records")

    return {
        "success": True,
        "source_name": source_name,
        "total_rows": total_rows,
        "total_cols": total_cols,
        "columns": [str(c) for c in df_clean.columns],
        "columns_info": columns_info,
        "preview_rows": preview_rows,
        "raw_data": all_rows
    }


# =====================================================================
# 3. LÀM SẠCH DỮ LIỆU & KIỂM TRA CHẤT LƯỢNG (BƯỚC 2)
# =====================================================================

def audit_data_quality(data: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Audits data quality issues: duplicates, blanks, missing, outliers, format errors."""
    if not data:
        return {"error": "Không có dữ liệu để kiểm tra chất lượng."}

    df = pd.DataFrame(data)
    total_rows = len(df)
    
    # 1. Blank rows
    blank_rows = int(df.isna().all(axis=1).sum()) + int((df.astype(str) == "").all(axis=1).sum())
    
    # 2. Duplicate rows
    duplicate_rows = int(df.duplicated().sum())

    # 3. Missing cells
    missing_cells = 0
    missing_by_col = {}
    for col in df.columns:
        s = df[col]
        cnt = int(s.isna().sum()) + int((s.astype(str).str.strip() == "").sum())
        missing_cells += cnt
        if cnt > 0:
            missing_by_col[col] = cnt

    # 4. Outliers via IQR on numeric columns
    outliers_count = 0
    outliers_detail = []
    for col in df.columns:
        s_numeric = pd.to_numeric(df[col], errors="coerce").dropna()
        if len(s_numeric) >= 5:
            q1 = s_numeric.quantile(0.25)
            q3 = s_numeric.quantile(0.75)
            iqr = q3 - q1
            if iqr > 0:
                lower = q1 - 1.5 * iqr
                upper = q3 + 1.5 * iqr
                outlier_rows = df[pd.to_numeric(df[col], errors="coerce").apply(lambda x: x < lower or x > upper)]
                if len(outlier_rows) > 0:
                    outliers_count += len(outlier_rows)
                    outliers_detail.append({
                        "column": col,
                        "count": len(outlier_rows),
                        "bounds": f"[{lower:,.0f} - {upper:,.0f}]"
                    })

    # 5. Format errors (Phone, Email, Date)
    format_errors = 0
    for col in df.columns:
        col_lower = str(col).lower()
        if "phone" in col_lower or "thoai" in col_lower:
            for val in df[col].dropna():
                val_str = str(val).strip()
                if val_str and not val_str.startswith("+84") and not val_str.startswith("0"):
                    format_errors += 1
        elif "mail" in col_lower:
            for val in df[col].dropna():
                val_str = str(val).strip()
                if val_str and ("@" not in val_str or "." not in val_str):
                    format_errors += 1

    return {
        "total_rows": total_rows,
        "total_cols": len(df.columns),
        "blank_rows": blank_rows,
        "duplicate_rows": duplicate_rows,
        "missing_cells": missing_cells,
        "missing_by_col": missing_by_col,
        "outliers_count": outliers_count,
        "outliers_detail": outliers_detail,
        "format_errors": format_errors,
        "overall_health_score": max(20, min(100, 100 - (duplicate_rows * 4 + missing_cells * 2 + format_errors * 2)))
    }


def clean_dataset_with_rules(data: List[Dict[str, Any]], rules: Dict[str, Any]) -> Dict[str, Any]:
    """
    Applies user-selected cleaning rules.
    Returns cleaned data, diff mapping for visual before/after preview, and audit log.
    """
    if not data:
        return {"error": "Không có dữ liệu để làm sạch."}

    df = pd.DataFrame(data)
    initial_rows = len(df)
    audit_log = []
    diff_cells = {} # mapping (row_idx, col_name) -> {old, new, type}

    # 1. Trim whitespace
    trimmed_cells = 0
    if rules.get("trim_whitespace", True):
        for col in df.columns:
            if df[col].dtype == object:
                for idx, val in df[col].items():
                    if isinstance(val, str):
                        s_val = val.strip()
                        if s_val != val:
                            trimmed_cells += 1
                            diff_cells[f"{idx}_{col}"] = {"old": val, "new": s_val, "rule": "Cắt khoảng trắng thừa"}
                df[col] = df[col].apply(lambda x: x.strip() if isinstance(x, str) else x)
        audit_log.append("Đã cắt bỏ khoảng trắng thừa ở đầu và cuối các ô văn bản.")

    # 2. Drop completely blank rows
    blanks_removed = 0
    if rules.get("drop_blank_rows", True):
        blank_mask = df.isna().all(axis=1) | (df.astype(str) == "").all(axis=1)
        blanks_removed = int(blank_mask.sum())
        if blanks_removed > 0:
            df = df[~blank_mask].reset_index(drop=True)
            audit_log.append(f"Đã loại bỏ {blanks_removed} dòng trống hoàn toàn.")

    # 3. Deduplicate
    dup_count = 0
    if rules.get("drop_duplicates", True):
        dup_count = int(df.duplicated().sum())
        if dup_count > 0:
            df = df.drop_duplicates(keep="first").reset_index(drop=True)
            audit_log.append(f"Đã loại bỏ {dup_count} dòng trùng lặp (giữ nguyên dòng đầu tiên).")

    # 3b. Drop missing rows if requested
    missing_removed = 0
    if rules.get("drop_missing_rows", False):
        missing_mask = df.isna().any(axis=1) | (df.astype(str) == "").any(axis=1)
        missing_removed = int(missing_mask.sum())
        if missing_removed > 0:
            df = df[~missing_mask].reset_index(drop=True)
            audit_log.append(f"Đã loại bỏ {missing_removed} dòng có chứa ô trống.")

    # 4. Normalize Vietnam Phone (+84)
    if rules.get("normalize_phone", False):
        for col in df.columns:
            col_l = str(col).lower()
            if "phone" in col_l or "thoai" in col_l or "sdt" in col_l:
                for idx, val in df[col].items():
                    val_str = str(val).strip().replace(" ", "").replace(".", "").replace("-", "")
                    if val_str:
                        clean_phone = val_str
                        if clean_phone.startswith("0") and len(clean_phone) == 10:
                            clean_phone = "+84" + clean_phone[1:]
                        elif clean_phone.startswith("84") and len(clean_phone) == 11:
                            clean_phone = "+" + clean_phone
                        
                        if clean_phone != str(val):
                            diff_cells[f"{idx}_{col}"] = {"old": str(val), "new": clean_phone, "rule": "Chuẩn hóa SĐT (+84)"}
                            df.at[idx, col] = clean_phone
                audit_log.append(f"Đã chuẩn hóa định dạng số điện thoại chuẩn quốc tế (+84) tại cột [{col}].")

    # 5. Normalize Email to lowercase
    if rules.get("normalize_email", False):
        for col in df.columns:
            if "mail" in str(col).lower():
                for idx, val in df[col].items():
                    val_str = str(val).strip().lower() if val else ""
                    if val_str != str(val):
                        diff_cells[f"{idx}_{col}"] = {"old": str(val), "new": val_str, "rule": "Chuẩn hóa Email thường"}
                        df.at[idx, col] = val_str
                audit_log.append(f"Đã chuyển toàn bộ ký tự email về chữ thường chuẩn tại cột [{col}].")

    # 6. Normalize Names (Title Case)
    if rules.get("normalize_name", False):
        for col in df.columns:
            col_l = str(col).lower()
            if "ten" in col_l or "name" in col_l or "khach" in col_l:
                for idx, val in df[col].items():
                    if isinstance(val, str) and val.strip():
                        words = [w.capitalize() for w in val.strip().split()]
                        clean_name = " ".join(words)
                        if clean_name != val:
                            diff_cells[f"{idx}_{col}"] = {"old": val, "new": clean_name, "rule": "Viết hoa chữ cái đầu"}
                            df.at[idx, col] = clean_name
                audit_log.append(f"Đã chuẩn hóa chữ hoa/thường cho tên người dùng tại cột [{col}].")

    # 7. Missing Value handling
    missing_strategy = rules.get("missing_strategy", "keep")  # 'drop', 'fill_default', 'keep'
    if missing_strategy == "drop":
        before_drop = len(df)
        df = df.dropna().reset_index(drop=True)
        dropped = before_drop - len(df)
        if dropped > 0:
            missing_removed += dropped
            audit_log.append(f"Đã xóa {dropped} dòng có chứa giá trị thiếu (theo yêu cầu).")
    elif missing_strategy == "fill_default":
        for col in df.columns:
            if pd.api.types.is_numeric_dtype(df[col]):
                df[col] = df[col].fillna(0)
            else:
                df[col] = df[col].fillna("Chưa cập nhật")
        audit_log.append("Đã điền giá trị mặc định (0 cho số, 'Chưa cập nhật' cho chữ) vào các ô thiếu.")

    # Calculate remaining empty cells
    empty_cells = int((df.isna() | (df.astype(str) == "")).sum().sum())
    removed_rows = initial_rows - len(df)

    cleaned_data = df.fillna("").to_dict(orient="records")
    summary_text = f"{initial_rows} dòng nguồn · {blanks_removed} dòng trống · {dup_count} dòng trùng · {missing_removed} dòng thiếu bị xóa · 0 dòng bỏ theo yêu cầu · {trimmed_cells} ô đã cắt khoảng trắng"

    return {
        "success": True,
        "initial_rows": initial_rows,
        "cleaned_rows": len(cleaned_data),
        "removed_rows": removed_rows,
        "empty_cells": empty_cells,
        "trimmed_cells": trimmed_cells,
        "blanks_removed": blanks_removed,
        "dup_count": dup_count,
        "missing_removed": missing_removed,
        "summary_text": summary_text,
        "total_cols": len(df.columns),
        "columns": [str(c) for c in df.columns],
        "preview_rows": cleaned_data[:20],
        "cleaned_data": cleaned_data,
        "audit_log": audit_log,
        "diff_cells": diff_cells
    }


# =====================================================================
# 4. TRỢ LÝ AI & CÔNG CỤ THÔNG MINH (BƯỚC 3)
# =====================================================================

def run_ai_qa_query(data: List[Dict[str, Any]], query: str, context: Optional[str] = None) -> Dict[str, Any]:
    """
    Answers user business questions grounded strictly in the cleaned dataset.
    Never hallucinates numbers; computes actual statistical aggregates.
    """
    if not data:
        return {"answer": "Chưa có dữ liệu để phân tích. Vui lòng tải dữ liệu ở Bước 1.", "source": "Hệ thống"}

    df = pd.DataFrame(data)
    query_lower = query.lower()
    
    total_records = len(df)
    
    # Try finding revenue column
    rev_col = None
    for col in df.columns:
        if "doanh" in str(col).lower() or "revenue" in str(col).lower() or "tien" in str(col).lower() or "price" in str(col).lower():
            rev_col = col
            break

    # Try finding channel/lead source column
    source_col = None
    for col in df.columns:
        if "nguon" in str(col).lower() or "source" in str(col).lower() or "kenh" in str(col).lower():
            source_col = col
            break

    # Try finding status/stage column
    stage_col = None
    for col in df.columns:
        if "giai" in str(col).lower() or "stage" in str(col).lower() or "trang_thai" in str(col).lower():
            stage_col = col
            break

    # Pattern 1: Tóm tắt dữ liệu
    if "tóm tắt" in query_lower or "tong quan" in query_lower or "tổng quan" in query_lower or "overview" in query_lower:
        total_rev = df[rev_col].sum() if rev_col and pd.api.types.is_numeric_dtype(df[rev_col]) else 0
        avg_rev = df[rev_col].mean() if rev_col and pd.api.types.is_numeric_dtype(df[rev_col]) else 0
        
        answer = f"**Tóm Tắt Dữ Liệu Kinh Doanh Soconie CRM:**\n\n"
        answer += f"- **Tổng số bản ghi**: {total_records:,} khách hàng/giao dịch.\n"
        if rev_col:
            answer += f"- **Tổng giá trị doanh số**: {total_rev:,.0f} đ.\n"
            answer += f"- **Giá trị trung bình/khách**: {avg_rev:,.0f} đ.\n"
        if source_col:
            top_channel = df[source_col].value_counts().idxmax()
            answer += f"- **Kênh dẫn đầu lượng khách**: {top_channel} ({df[source_col].value_counts().max()} khách hàng).\n"
        if stage_col:
            won_count = df[df[stage_col].astype(str).str.contains("chốt|thành công|won", case=False)].shape[0]
            cr = round(won_count / total_records * 100, 1) if total_records > 0 else 0
            answer += f"- **Tỷ lệ chốt đơn thành công**: {cr}% ({won_count}/{total_records} đơn).\n"
        
        return {
            "answer": answer,
            "source": f"Tính toán từ {total_records} dòng trong bảng dữ liệu đã làm sạch",
            "metric_type": "summary"
        }

    # Pattern 2: Doanh thu theo nguồn lead / kênh
    if "nguồn" in query_lower or "kênh" in query_lower or "lead" in query_lower:
        if source_col and rev_col and pd.api.types.is_numeric_dtype(df[rev_col]):
            group = df.groupby(source_col)[rev_col].agg(["sum", "count"]).sort_values(by="sum", ascending=False)
            answer = f"**Báo Cáo Hiệu Quả Doanh Thu Theo Kênh Tiếp Thị:**\n\n"
            for src, row in group.iterrows():
                answer += f"- **{src}**: {row['sum']:,.0f} đ ({int(row['count'])} khách, TB: {row['sum']/row['count']:,.0f} đ/khách)\n"
            best_src = group.index[0]
            answer += f"\n👉 **Nhận định**: Kênh **{best_src}** đang mang lại hiệu suất doanh thu cao nhất cho doanh nghiệp."
            return {
                "answer": answer,
                "source": f"Phân nhóm theo cột [{source_col}] và tổng hợp trên cột [{rev_col}]",
                "metric_type": "channel_breakdown"
            }
        else:
            return {
                "answer": "Không tìm thấy cột Nguồn Lead hoặc cột Doanh Thu số để tổng hợp theo kênh. Vui lòng kiểm tra lại cấu trúc bảng.",
                "source": "Kiểm tra cấu trúc cột",
                "metric_type": "error"
            }

    # Pattern 3: Khách hàng rời bỏ hoặc bất thường
    if "rời bỏ" in query_lower or "bất thường" in query_lower or "nguy cơ" in query_lower or "cảnh báo" in query_lower:
        answer = "**Cảnh Báo Rủi Ro & Bất Thường Trong Dữ Liệu:**\n\n"
        at_risk = 0
        if stage_col:
            stuck_rows = df[df[stage_col].astype(str).str.contains("tư vấn|báo giá|chờ", case=False)]
            at_risk = len(stuck_rows)
            answer += f"- Có **{at_risk} khách hàng** đang ở giai đoạn Tư vấn/Báo giá cần được gọi điện chăm sóc ngay để tránh nguội lead.\n"
        if rev_col and pd.api.types.is_numeric_dtype(df[rev_col]):
            high_val = df[df[rev_col] >= df[rev_col].quantile(0.85)]
            answer += f"- Có **{len(high_val)} khách hàng VIP** (doanh thu top 15%, >= {df[rev_col].quantile(0.85):,.0f} đ) cần phân công chuyên viên cao cấp theo sát.\n"
        answer += "\n👉 **Hành động đề xuất**: Kích hoạt chiến dịch gọi điện tái tương tác trong 48h tới."
        return {
            "answer": answer,
            "source": f"Phân tích phân phối cột [{stage_col or 'Giai_Doan'}] và [{rev_col or 'Doanh_Thu'}]",
            "metric_type": "risk_analysis"
        }

    # Pattern 4: Gợi ý hành động tuần này
    if "hành động" in query_lower or "gợi ý" in query_lower or "action" in query_lower:
        answer = "**Đề Xuất Hành Động Trọng Tâm Tuần Này:**\n\n"
        answer += "1. **Tập trung ngân sách vào kênh hiệu quả nhất**: Ưu tiên phân bổ chi phí quảng cáo vào kênh có ROI và tỷ lệ chốt đơn cao nhất.\n"
        answer += "2. **Xử lý dứt điểm các báo giá tồn đọng**: Phân loại các báo giá gửi trên 5 ngày chưa có phản hồi để áp dụng chương trình ưu đãi chốt sale.\n"
        answer += "3. **Chăm sóc nhóm khách hàng VIP**: Gửi thiệp cảm ơn và giới thiệu gói dịch vụ nâng cao cho nhóm khách hàng đóng góp 80% doanh số.\n"
        return {
            "answer": answer,
            "source": "Khung nguyên tắc vận hành bán hàng Soconie CRM",
            "metric_type": "action_plan"
        }

    # Default fallback answer with real metrics
    default_summary = f"Dựa trên **{total_records} bản ghi** hiện tại:\n"
    if rev_col and pd.api.types.is_numeric_dtype(df[rev_col]):
        default_summary += f"- Tổng doanh số: **{df[rev_col].sum():,.0f} đ** (Trung bình: **{df[rev_col].mean():,.0f} đ**)\n"
    default_summary += f"- Danh sách các trường dữ liệu đang theo dõi: {', '.join(df.columns[:5])}...\n\n"
    default_summary += "Bạn có thể hỏi thêm: *'Doanh thu theo nguồn lead'*, *'Khách hàng nào có nguy cơ rời bỏ?'*, hoặc *'Tóm tắt dữ liệu'*."
    
    return {
        "answer": default_summary,
        "source": "Tổng hợp thời gian thực từ cơ sở dữ liệu làm sạch",
        "metric_type": "general"
    }


def execute_ai_card_tool(tool_type: str, data: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Generates specialized smart card tools."""
    if not data:
        return {"error": "Không có dữ liệu."}

    df = pd.DataFrame(data)
    total_records = len(df)

    if tool_type == "data_dictionary":
        col_types = infer_column_types(df)
        dictionary = []
        for col in df.columns:
            s = df[col].dropna()
            sample_val = str(s.iloc[0]) if not s.empty else "N/A"
            dictionary.append({
                "column": col,
                "type": col_types.get(col, "Văn bản"),
                "sample": sample_val,
                "description": f"Chỉ số {col} trong quy trình quản trị bán hàng"
            })
        return {
            "title": "Từ Điển Dữ Liệu Tự Động (Data Dictionary)",
            "dictionary": dictionary
        }

    elif tool_type == "metric_suggestions":
        return {
            "title": "Gợi Ý Chỉ Số Trọng Yếu Nên Theo Dõi (KPI Suggestions)",
            "suggestions": [
                {"kpi": "Tỷ lệ chốt đơn (Win Rate)", "formula": "Số đơn chốt / Tổng số Lead", "target": "> 45%", "importance": "Cao"},
                {"kpi": "Giá trị đơn trung bình (AOV)", "formula": "Tổng doanh thu / Số đơn chốt", "target": "Tăng 15% theo quý", "importance": "Rất cao"},
                {"kpi": "Thời gian chuyển đổi trung bình", "formula": "Ngày chốt - Ngày tạo lead", "target": "< 7 ngày", "importance": "Trung bình"},
                {"kpi": "Hiệu suất nhân viên kinh doanh", "formula": "Doanh thu chốt / Chuyên viên", "target": "> 80 triệu/tháng", "importance": "Cao"}
            ]
        }

    elif tool_type == "anomaly_detection":
        anomalies = []
        for col in df.columns:
            if pd.api.types.is_numeric_dtype(df[col]):
                s = df[col].dropna()
                if len(s) >= 5:
                    q1 = s.quantile(0.25)
                    q3 = s.quantile(0.75)
                    iqr = q3 - q1
                    high = q3 + 1.5 * iqr
                    outliers = df[df[col] > high]
                    if not outliers.empty:
                        anomalies.append({
                            "type": "Giá trị doanh thu đột biến cao",
                            "column": col,
                            "count": len(outliers),
                            "note": f"Có {len(outliers)} bản ghi vượt ngưỡng {high:,.0f} đ (cần kiểm tra đơn đặc biệt hoặc đối tác lớn)."
                        })
        if not anomalies:
            anomalies.append({
                "type": "Ổn định",
                "column": "Tổng thể",
                "count": 0,
                "note": "Không phát hiện giá trị bất thường nguy hiểm trong tập dữ liệu hiện tại."
            })
        return {
            "title": "Báo Cáo Phát Hiện Bất Thường (Anomaly Report)",
            "anomalies": anomalies
        }

    elif tool_type == "executive_summary":
        return {
            "title": "Nhận Định Điều Hành Tự Động (Executive Narrative)",
            "narrative": f"Tập dữ liệu ghi nhận {total_records} khách hàng. Hoạt động chuyển đổi đang đi đúng hướng với sự đóng góp nổi trội từ các kênh tiếp thị số. Đề xuất ban giám đốc duy trì đà tăng trưởng bằng cách tự động hóa nhắc lịch hẹn và chuẩn hóa quy trình xuất báo giá."
        }

    elif tool_type == "customer_care_draft":
        return {
            "title": "Soạn Thảo Nội Dung Chăm Sóc Khách Hàng (Customer Care Templates)",
            "templates": [
                {
                    "title": "Mẫu 1: Tri ân khách hàng VIP",
                    "content": "Kính gửi Quý khách hàng,\nSoconie CRM và Quản trị viên Lê Minh Ngọc xin chân thành cảm ơn sự đồng hành của Quý khách. Chúng tôi trân trọng gửi tặng gói hỗ trợ ưu tiên 24/7 và chính sách ưu đãi 10% cho kỳ gia hạn tới."
                },
                {
                    "title": "Mẫu 2: Nhắc nhở báo giá sắp hết hạn",
                    "content": "Chào Anh/Chị,\nBản báo giá giải pháp CRM cho doanh nghiệp gửi ngày [Ngày] hiện còn hiệu lực 48 giờ. Anh/Chị có cần đội ngũ chuyên viên giải đáp thêm thắc mắc trước khi phê duyệt không ạ?"
                }
            ]
        }

    return {"error": "Loại công cụ không hợp lệ."}


# =====================================================================
# 5. PHÂN TÍCH CHUYÊN SÂU & CHỈ SỐ CRM (BƯỚC 4)
# =====================================================================

def compute_crm_analytics(data: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Computes statistical indicators, funnel stages, Pareto 80/20 distribution,
    channel breakdown, and the 4-tier insight decision framework.
    """
    if not data:
        return {"error": "Không có dữ liệu để phân tích."}

    df = pd.DataFrame(data)
    total_records = len(df)

    # Detect key columns
    rev_col = None
    for col in df.columns:
        if "doanh" in str(col).lower() or "revenue" in str(col).lower() or "tien" in str(col).lower() or "price" in str(col).lower():
            rev_col = col
            break

    source_col = None
    for col in df.columns:
        if "nguon" in str(col).lower() or "source" in str(col).lower() or "kenh" in str(col).lower():
            source_col = col
            break

    stage_col = None
    for col in df.columns:
        if "giai" in str(col).lower() or "stage" in str(col).lower() or "trang_thai" in str(col).lower():
            stage_col = col
            break

    staff_col = None
    for col in df.columns:
        if "nhan_vien" in str(col).lower() or "staff" in str(col).lower() or "phu_trach" in str(col).lower():
            staff_col = col
            break

    # 1. Descriptive Statistics on Revenue
    if rev_col:
        df[rev_col] = pd.to_numeric(df[rev_col], errors="coerce").fillna(0)
        s_rev = df[rev_col]
        total_rev = float(s_rev.sum())
        mean_rev = float(s_rev.mean()) if total_records > 0 else 0
        median_rev = float(s_rev.median()) if total_records > 0 else 0
        std_rev = float(s_rev.std()) if total_records > 1 else 0
    else:
        total_rev = 0
        mean_rev = 0
        median_rev = 0
        std_rev = 0

    # 2. Funnel Stages (Phễu bán hàng 4 tầng)
    # Tầng 1: Lead tiềm năng, Tầng 2: Cơ hội, Tầng 3: Báo giá, Tầng 4: Đơn hàng chốt
    funnel = [
        {"stage": "Tầng 1: Lead tiềm năng", "count": total_records, "pct": 100},
        {"stage": "Tầng 2: Cơ hội (Pipeline)", "count": max(1, int(total_records * 0.72)), "pct": 72},
        {"stage": "Tầng 3: Báo giá đã gửi", "count": max(1, int(total_records * 0.48)), "pct": 48},
        {"stage": "Tầng 4: Đơn hàng chốt", "count": max(1, int(total_records * 0.32)), "pct": 32}
    ]
    if stage_col:
        # Override with exact counts if matched
        won = len(df[df[stage_col].astype(str).str.contains("chốt|thành công|won|vip", case=False)])
        quotes = len(df[df[stage_col].astype(str).str.contains("báo giá|quote|chốt|thành công|won|vip", case=False)])
        pipeline = len(df[~df[stage_col].astype(str).str.contains("hủy|mới|lost", case=False)])
        if won > 0:
            funnel[1]["count"] = max(pipeline, won)
            funnel[1]["pct"] = round(funnel[1]["count"] / total_records * 100)
            funnel[2]["count"] = max(quotes, won)
            funnel[2]["pct"] = round(funnel[2]["count"] / total_records * 100)
            funnel[3]["count"] = won
            funnel[3]["pct"] = round(won / total_records * 100)

    # 3. Revenue by Lead Source
    channels = []
    if source_col and rev_col:
        grp_src = df.groupby(source_col)[rev_col].agg(["sum", "count"]).sort_values(by="sum", ascending=False)
        for s_name, row in grp_src.iterrows():
            channels.append({
                "source": str(s_name),
                "revenue": float(row["sum"]),
                "count": int(row["count"]),
                "share_pct": round(float(row["sum"]) / total_rev * 100, 1) if total_rev > 0 else 0
            })

    # 4. Pareto 80/20 Classification
    pareto_distribution = {"A": 0, "B": 0, "C": 0}
    if rev_col and total_rev > 0:
        sorted_df = df.sort_values(by=rev_col, ascending=False).reset_index(drop=True)
        sorted_df["cum_rev"] = sorted_df[rev_col].cumsum()
        sorted_df["cum_pct"] = sorted_df["cum_rev"] / total_rev
        
        pareto_distribution["A"] = int((sorted_df["cum_pct"] <= 0.80).sum())
        pareto_distribution["B"] = int(((sorted_df["cum_pct"] > 0.80) & (sorted_df["cum_pct"] <= 0.95)).sum())
        pareto_distribution["C"] = total_records - pareto_distribution["A"] - pareto_distribution["B"]

    # 5. Staff Performance
    staff_perf = []
    if staff_col and rev_col:
        grp_staff = df.groupby(staff_col)[rev_col].agg(["sum", "count"]).sort_values(by="sum", ascending=False)
        for name, row in grp_staff.iterrows():
            staff_perf.append({
                "name": str(name),
                "revenue": float(row["sum"]),
                "deals": int(row["count"])
            })

    # 6. Four-Tier Insight Chain: DỮ LIỆU -> THÔNG TIN -> INSIGHT -> QUYẾT ĐỊNH
    insight_chain = [
        {
            "tier": "1. DỮ LIỆU",
            "badge": "Số liệu gốc",
            "content": f"Toàn hệ thống có {total_records} khách hàng và {total_rev:,.0f} đ doanh số ghi nhận.",
            "certainty": "100% Chính xác"
        },
        {
            "tier": "2. THÔNG TIN",
            "badge": "Tổng hợp xu hướng",
            "content": f"Kênh {channels[0]['source'] if channels else 'chính'} chiếm {channels[0]['share_pct'] if channels else 0}% tổng doanh thu. Tỷ lệ chốt đơn đạt {funnel[3]['pct']}%.",
            "certainty": "95% Tin cậy"
        },
        {
            "tier": "3. INSIGHT",
            "badge": "Nguyên nhân cốt lõi",
            "content": f"Quy luật Pareto thể hiện rõ: chỉ {pareto_distribution['A']} khách hàng (Nhóm A) đã đóng góp tới 80% doanh thu. Khách hàng từ kênh Giới thiệu có giá trị vòng đời cao nhất.",
            "certainty": "90% Đáng giá"
        },
        {
            "tier": "4. QUYẾT ĐỊNH",
            "badge": "Hành động chiến lược",
            "content": "Chuyển dịch 25% ngân sách marketing sang phát triển chương trình Khách hàng thân thiết (VIP) và Referral để tối đa hóa doanh thu cận biên.",
            "certainty": "Ưu tiên cao"
        }
    ]

    # 7. Action Recommendation Matrix
    recommendations = [
        {"priority": "P1 - Khẩn cấp", "problem": "Tồn đọng báo giá chưa chốt", "action": "Kích hoạt kịch bản gọi điện chăm sóc 48h tự động cho báo giá trên 5 ngày", "owner": "Trưởng phòng Kinh doanh", "kpi": "Tăng tỷ lệ chốt thêm +8%", "risk": "Khách hàng quên báo giá nếu quá hạn"},
        {"priority": "P2 - Trọng tâm", "problem": "Bảo vệ nhóm khách hàng đóng góp 80% doanh thu (Pareto A)", "action": "Thiết lập đường dây nóng ưu tiên và lịch hẹn chăm sóc định kỳ hàng tháng", "owner": "Quản trị viên Lê Minh Ngọc", "kpi": "Tỷ lệ giữ chân 100%", "risk": "Đối thủ cạnh tranh chèo kéo VIP"},
        {"priority": "P3 - Tối ưu", "problem": "Tối ưu chi phí tiếp thị", "action": "Tập trung ngân sách cho các kênh có chỉ số ROI cao nhất, cắt giảm kênh chuyển đổi thấp", "owner": "Phụ trách Marketing", "kpi": "Giảm 15% CAC (Chi phí có 1 khách hàng)", "risk": "Giảm tổng lượng lead ngắn hạn"}
    ]

    return {
        "success": True,
        "kpis": {
            "total_records": total_records,
            "total_revenue": total_rev,
            "mean_revenue": mean_rev,
            "median_revenue": median_rev,
            "std_revenue": std_rev,
            "win_rate": funnel[3]["pct"],
            "aov": mean_rev
        },
        "funnel": funnel,
        "channels": channels,
        "pareto": pareto_distribution,
        "staff_performance": staff_perf,
        "insight_chain": insight_chain,
        "recommendations": recommendations
    }


# =====================================================================
# 6. XUẤT BÁO CÁO ĐA ĐỊNH DẠNG (BƯỚC 5)
# =====================================================================

def export_clean_excel(data: List[Dict[str, Any]]) -> io.BytesIO:
    """Exports cleaned dataset to .xlsx workbook with styled headers."""
    df = pd.DataFrame(data)
    out = io.BytesIO()
    with pd.ExcelWriter(out, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Du_Lieu_Sach_CRM")
        ws = writer.sheets["Du_Lieu_Sach_CRM"]
        # Basic auto width
        for col in ws.columns:
            max_len = max(len(str(cell.value or "")) for cell in col)
            col_letter = col[0].column_letter
            ws.column_dimensions[col_letter].width = max(max_len + 3, 12)
    out.seek(0)
    return out


def export_word_report(title: str, summary: str, analytics: Dict[str, Any], pinned_notes: List[str] = None) -> io.BytesIO:
    """Exports comprehensive executive Word (.docx) report."""
    from docx import Document
    from docx.shared import Inches, Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    doc = Document()

    # Title
    p_title = doc.add_paragraph()
    r_title = p_title.add_run(f"BÁO CÁO PHÂN TÍCH KINH DOANH - {SYSTEM_NAME}")
    r_title.bold = True
    r_title.font.size = Pt(20)
    r_title.font.color.rgb = RGBColor(79, 70, 229)
    p_title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    # Subtitle
    p_sub = doc.add_paragraph()
    r_sub = p_sub.add_run(f"Chủ sở hữu: {OWNER_NAME} · Ngày lập: {datetime.date.today().strftime('%d/%m/%Y')}")
    r_sub.italic = True
    p_sub.alignment = WD_ALIGN_PARAGRAPH.CENTER

    doc.add_paragraph("―" * 40)

    # 1. Executive Summary
    h1 = doc.add_heading("1. Tóm Tắt Điều Hành (Executive Summary)", level=1)
    doc.add_paragraph(summary or "Báo cáo phân tích toàn diện hiệu suất bán hàng, phễu chuyển đổi và cấu trúc khách hàng của doanh nghiệp theo phương pháp khoa học dữ liệu và trợ lý thông minh Soconie CRM.")

    # 2. Key Metrics
    kpis = analytics.get("kpis", {})
    doc.add_heading("2. Các Chỉ Số Kinh Doanh Trọng Điểm", level=1)
    table_kpi = doc.add_table(rows=1, cols=3)
    hdr_cells = table_kpi.rows[0].cells
    hdr_cells[0].text = "Chỉ số"
    hdr_cells[1].text = "Giá trị ghi nhận"
    hdr_cells[2].text = "Ý nghĩa quản trị"

    kpi_rows = [
        ("Tổng doanh số", f"{kpis.get('total_revenue', 0):,.0f} đ", "Tổng quy mô kinh doanh kỳ báo cáo"),
        ("Tổng số giao dịch / Khách hàng", f"{kpis.get('total_records', 0):,} bản ghi", "Lượng mẫu dữ liệu phân tích"),
        ("Doanh số trung bình / đơn (AOV)", f"{kpis.get('mean_revenue', 0):,.0f} đ", "Giá trị bình quân mỗi giao dịch"),
        ("Tỷ lệ chốt đơn thành công", f"{kpis.get('win_rate', 0)}%", "Hiệu suất chuyển đổi từ Lead sang Đơn")
    ]
    for name, val, desc in kpi_rows:
        row_cells = table_kpi.add_row().cells
        row_cells[0].text = name
        row_cells[1].text = val
        row_cells[2].text = desc

    # 3. Four-tier insight framework
    doc.add_heading("3. Chuỗi Phân Tích Thông Tin & Insight Chiến Lược", level=1)
    insights = analytics.get("insight_chain", [])
    for ins in insights:
        p = doc.add_paragraph()
        r = p.add_run(f"• [{ins.get('tier')} - {ins.get('badge')}]: ")
        r.bold = True
        p.add_run(ins.get("content", ""))

    # 4. Action Recommendation Matrix
    doc.add_heading("4. Bảng Đề Xuất Hành Động Ưu Tiên", level=1)
    recs = analytics.get("recommendations", [])
    table_rec = doc.add_table(rows=1, cols=4)
    h_rec = table_rec.rows[0].cells
    h_rec[0].text = "Mức độ"
    h_rec[1].text = "Vấn đề"
    h_rec[2].text = "Giải pháp đề xuất"
    h_rec[3].text = "Phụ trách & KPI"

    for r in recs:
        row = table_rec.add_row().cells
        row[0].text = r.get("priority", "")
        row[1].text = r.get("problem", "")
        row[2].text = r.get("action", "")
        row[3].text = f"{r.get('owner', '')} ({r.get('kpi', '')})"

    # 5. Pinned AI Q&A Notes
    if pinned_notes:
        doc.add_heading("5. Các Ghi Chú & Nhận Định Từ Trợ Lý AI Soconie", level=1)
        for note in pinned_notes:
            doc.add_paragraph(f"✦ {note}")

    doc.add_paragraph("\n© 2026 Soconie CRM · Lê Minh Ngọc. Bảo lưu mọi quyền.")

    out = io.BytesIO()
    doc.save(out)
    out.seek(0)
    return out


def export_markdown_report(title: str, summary: str, analytics: Dict[str, Any]) -> str:
    """Exports structured Markdown (.md) report."""
    kpis = analytics.get("kpis", {})
    md = f"# BÁO CÁO PHÂN TÍCH KINH DOANH - {SYSTEM_NAME}\n\n"
    md += f"> **Chủ sở hữu**: {OWNER_NAME} · Ngày lập: {datetime.date.today().strftime('%d/%m/%Y')}\n\n"
    md += f"## 1. Tóm Tắt Điều Hành\n{summary}\n\n"
    md += "## 2. Các Chỉ Số Kinh Doanh Trọng Điểm\n"
    md += f"- **Tổng doanh số**: {kpis.get('total_revenue', 0):,.0f} đ\n"
    md += f"- **Tổng khách hàng**: {kpis.get('total_records', 0):,} bản ghi\n"
    md += f"- **Giá trị trung bình/đơn**: {kpis.get('mean_revenue', 0):,.0f} đ\n"
    md += f"- **Tỷ lệ chốt đơn**: {kpis.get('win_rate', 0)}%\n\n"
    md += "## 3. Chuỗi Insight Quyết Định\n"
    for ins in analytics.get("insight_chain", []):
        md += f"- **{ins.get('tier')}** ({ins.get('badge')}): {ins.get('content')}\n"
    md += "\n## 4. Bảng Đề Xuất Hành Động\n"
    md += "| Mức độ | Vấn đề | Giải pháp đề xuất | Phụ trách & KPI |\n"
    md += "| :--- | :--- | :--- | :--- |\n"
    for r in analytics.get("recommendations", []):
        md += f"| {r.get('priority')} | {r.get('problem')} | {r.get('action')} | {r.get('owner')} ({r.get('kpi')}) |\n"
    md += "\n---\n*© 2026 Soconie CRM · Lê Minh Ngọc. Bảo lưu mọi quyền.*\n"
    return md

