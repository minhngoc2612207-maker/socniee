"""
Automated Test Suite for Soconie CRM - Analysis Studio & Landing Experience
"""
import sys
import time
import math
import requests
import sqlite3

BASE_URL = "http://127.0.0.1:5000"


def get_verified_captcha_token(action="contact"):
    res = requests.get(f"{BASE_URL}/api/captcha/challenge?action={action}")
    data = res.json()
    assert data["success"] is True
    cid = data["challenge_id"]

    conn = sqlite3.connect("crm/data/crm.db")
    c = conn.cursor()
    c.execute("SELECT correct_x FROM captcha_challenges WHERE challenge_id = ?", (cid,))
    row = c.fetchone()
    conn.close()
    assert row is not None
    actual_x = row[0]

    trail = []
    steps = 15
    duration_ms = 800
    for i in range(steps):
        t_frac = i / (steps - 1)
        cur_x = actual_x * (1 - (1 - t_frac)**2)
        cur_y = 1.8 * math.sin(t_frac * 3.14)
        trail.append({
            "x": round(cur_x, 1),
            "y": round(cur_y, 1),
            "t": int(t_frac * duration_ms)
        })

    ver_res = requests.post(f"{BASE_URL}/api/captcha/verify", json={
        "challenge_id": cid,
        "final_x": actual_x,
        "trail": trail,
        "action": action
    })
    ver_data = ver_res.json()
    assert ver_data["success"] is True
    return ver_data["captcha_token"]


def test_landing_and_analysis():
    print("--- 1. Testing Landing Page Navigation Sections ---")
    r_landing = requests.get(f"{BASE_URL}/")
    assert r_landing.status_code == 200
    html = r_landing.text
    for sec in ['id="tinh-nang"', 'id="quy-trinh"', 'id="bang-gia"', 'id="gioi-thieu"', 'id="lien-he"']:
        assert sec in html, f"Missing section {sec} on landing page!"
    print("  [OK] All 5 sections (#tinh-nang, #quy-trinh, #bang-gia, #gioi-thieu, #lien-he) exist!")

    print("\n--- 2. Testing 3 Landing Cards Click Handlers & Modals ---")
    assert "openFeaturePreview('customer360')" in html
    assert "openFeaturePreview('pipeline')" in html
    assert "openFeaturePreview('dashboard')" in html
    assert "showCustomer360Modal" in html
    assert "showPipelineModal" in html
    print("  [OK] All 3 cards have interactive handlers and demo modals attached!")

    print("\n--- 3. Testing Contact Form with CAPTCHA Submission ---")
    contact_token = get_verified_captcha_token("contact")
    contact_payload = {
        "full_name": "Công ty TNHH Hoàng Gia",
        "contact": "0988776655",
        "need": "Báo giá gói Chuyên nghiệp",
        "message": "Cần tư vấn triển khai cho đội ngũ 15 nhân sự bán hàng.",
        "terms": True,
        "captcha_token": contact_token
    }
    r_contact = requests.post(f"{BASE_URL}/api/contact", json=contact_payload)
    data_contact = r_contact.json()
    assert data_contact["success"] is True, f"Contact submission failed: {data_contact}"
    assert "Lê Minh Ngọc sẽ phản hồi" in data_contact["message"]
    print(f"  [OK] Contact inquiry submitted successfully! Message: {data_contact['message']}")

    print("\n--- 4. Testing Analysis Studio Page Load ---")
    r_studio = requests.get(f"{BASE_URL}/khong-gian-phan-tich")
    assert r_studio.status_code == 200
    s_html = r_studio.text
    assert "Không gian phân tích" in s_html
    assert "Nhập dữ liệu" in s_html
    assert "Làm sạch" in s_html
    assert "Công cụ AI" in s_html
    assert "Phân tích dữ liệu" in s_html
    assert "Báo cáo" in s_html
    print("  [OK] Không gian phân tích studio rendered 200 OK with all 5 steps!")

    print("\n--- 5. Testing Step 1: Loading Sample & CRM Data ---")
    r_sample = requests.post(f"{BASE_URL}/api/analysis/load-sample")
    d_sample = r_sample.json()
    assert d_sample["success"] is True
    assert d_sample["total_rows"] > 0
    assert len(d_sample["columns"]) >= 5
    raw_data = d_sample["raw_data"]
    print(f"  [OK] Loaded sample CRM dataset: {d_sample['total_rows']} rows, {len(d_sample['columns'])} columns!")

    r_crm = requests.post(f"{BASE_URL}/api/analysis/load-crm")
    d_crm = r_crm.json()
    assert d_crm["success"] is True
    print(f"  [OK] Loaded internal SQLite CRM dataset: {d_crm['total_rows']} rows!")

    print("\n--- 6. Testing Step 2: Quality Audit & Cleaning Rules ---")
    r_audit = requests.post(f"{BASE_URL}/api/analysis/audit", json={"data": raw_data})
    d_audit = r_audit.json()
    assert d_audit["success"] is True
    q = d_audit["quality"]
    assert "overall_health_score" in q
    print(f"  [OK] Quality audit completed: {q['duplicate_rows']} duplicates, {q['missing_cells']} missing, Health: {q['overall_health_score']}/100")

    r_clean = requests.post(f"{BASE_URL}/api/analysis/clean", json={
        "data": raw_data,
        "rules": {
            "trim_whitespace": True,
            "drop_blank_rows": True,
            "drop_duplicates": True,
            "normalize_phone": True,
            "normalize_email": True,
            "normalize_name": True,
            "missing_strategy": "keep"
        }
    })
    d_clean = r_clean.json()
    assert d_clean["success"] is True
    cleaned_rows = d_clean["cleaned_data"]
    print(f"  [OK] Data cleaned: Initial {d_clean['initial_rows']} -> Cleaned {d_clean['cleaned_rows']} rows. Diff cells tracked: {len(d_clean['diff_cells'])}")

    print("\n--- 7. Testing Step 3: Grounded AI Assistant Q&A & Smart Tools ---")
    r_ai = requests.post(f"{BASE_URL}/api/analysis/ai-chat", json={
        "query": "Tóm tắt dữ liệu",
        "data": cleaned_rows
    })
    d_ai = r_ai.json()
    assert d_ai["success"] is True
    ans = d_ai["result"]["answer"]
    assert "Tóm Tắt Dữ Liệu" in ans
    assert "Tổng giá trị doanh số" in ans
    print(f"  [OK] Grounded AI Q&A verified! Source: {d_ai['result']['source']}")

    r_tool = requests.post(f"{BASE_URL}/api/analysis/ai-tool", json={
        "tool_type": "data_dictionary",
        "data": cleaned_rows
    })
    d_tool = r_tool.json()
    assert d_tool["success"] is True
    assert "dictionary" in d_tool["result"]
    print(f"  [OK] Smart card tool generated: {d_tool['result']['title']}")

    print("\n--- 8. Testing Step 4: CRM Analytics, Funnel & Pareto ---")
    r_compute = requests.post(f"{BASE_URL}/api/analysis/compute", json={"data": cleaned_rows})
    d_compute = r_compute.json()
    assert d_compute["success"] is True
    assert len(d_compute["funnel"]) == 4
    assert len(d_compute["insight_chain"]) == 4
    assert len(d_compute["recommendations"]) >= 3
    print(f"  [OK] Analytics computed: Funnel 4 stages, Pareto {d_compute['pareto']}, Win Rate: {d_compute['kpis']['win_rate']}%")

    print("\n--- 9. Testing Step 5: Multi-Format Report Exports (.xlsx, .docx, .md, .json) ---")
    for fmt in ["excel_clean", "word", "markdown", "audit"]:
        r_exp = requests.post(f"{BASE_URL}/api/analysis/export", json={
            "format": fmt,
            "data": cleaned_rows,
            "analytics": d_compute,
            "title": "Báo Cáo Thử Nghiệm Soconie",
            "summary": "Tóm tắt điều hành kiểm thử tự động."
        })
        assert r_exp.status_code == 200, f"Export {fmt} failed with code {r_exp.status_code}"
        assert len(r_exp.content) > 50, f"Export {fmt} produced empty payload!"
        print(f"  [OK] Exported {fmt}: {len(r_exp.content):,} bytes received!")

    print("\n--- 10. Testing Step 5: Save Report to Database & Share View ---")
    r_save = requests.post(f"{BASE_URL}/api/analysis/save-report", json={
        "title": "Báo cáo quý 1 2026",
        "summary": "Tóm tắt kiểm thử lưu trữ",
        "dataset_name": "CRM_Kinh_Doanh_2026.csv",
        "report_data": {"analytics": d_compute}
    })
    d_save = r_save.json()
    assert d_save["success"] is True
    share_url = d_save["share_url"]
    share_token = d_save["share_token"]
    print(f"  [OK] Report saved! ID={d_save['report_id']}, Share URL: {share_url}")

    r_share = requests.get(f"{BASE_URL}/bao-cao/chia-se/{share_token}")
    assert r_share.status_code == 200
    assert "Báo cáo chia sẻ" in r_share.text
    print("  [OK] Shared read-only report view rendered 200 OK!")

    print("\n================ ALL LANDING & ANALYSIS TESTS PASSED ================\n")


if __name__ == "__main__":
    test_landing_and_analysis()
