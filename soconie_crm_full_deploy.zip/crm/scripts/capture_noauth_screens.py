"""
Capture screenshots verifying the complete removal of auth gates
"""
import os
import shutil
import tempfile
import subprocess

chrome_path = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
artifact_dir = r"C:\Users\THC\.gemini\antigravity\brain\985b2eed-7902-4b89-b84c-58315124fe59"
temp_dir = tempfile.gettempdir()

targets = [
    ("shot_noauth_landing_hero.png", "http://localhost:5000/?theme=light", 1440, 950),
    ("shot_noauth_welcome_card.png", "http://localhost:5000/?screen=welcome&theme=light", 1440, 950),
    ("shot_noauth_crm_dashboard.png", "http://localhost:5000/tong-quan?theme=light", 1440, 950),
    ("shot_noauth_customers_360.png", "http://localhost:5000/khach-hang?theme=light", 1440, 950),
]

for filename, url, w, h in targets:
    tmp_out = os.path.join(temp_dir, "tmp_" + filename)
    if os.path.exists(tmp_out):
        try:
            os.remove(tmp_out)
        except:
            pass

    cmd = [
        chrome_path,
        "--headless=new",
        "--disable-gpu",
        "--no-sandbox",
        f"--window-size={w},{h}",
        "--hide-scrollbars",
        "--virtual-time-budget=3000",
        f"--screenshot={tmp_out}",
        url
    ]
    try:
        subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20)
        dst = os.path.join(artifact_dir, filename)
        if os.path.exists(tmp_out):
            shutil.copyfile(tmp_out, dst)
            sz = os.path.getsize(dst)
            print(f"[OK] Captured {filename}: {sz:,} bytes")
        else:
            print(f"[FAIL] Could not generate {filename}")
    except Exception as e:
        print(f"[ERROR] Capturing {filename}:", e)
