"""
CaptchaProvider Adapter Interface for Soconie CRM.
Supports Slider Puzzle (local), Cloudflare Turnstile, and hCaptcha.
"""
import abc
from datetime import datetime, timedelta
from typing import Dict, Any, Optional

from crm.database import execute_db
from crm.site_config import CAPTCHA_TTL_SECONDS, CAPTCHA_PROVIDER
from crm.captcha.generator import generate_puzzle_challenge
from crm.captcha.validator import verify_captcha_challenge, issue_captcha_token


class CaptchaProvider(abc.ABC):
    """Abstract interface for CAPTCHA providers."""

    @abc.abstractmethod
    def create_challenge(self, action: str = "register", ip_address: str = "127.0.0.1") -> Dict[str, Any]:
        """Generates new challenge payload for client consumption."""
        pass

    @abc.abstractmethod
    def verify(self, payload: Dict[str, Any], ip_address: str = "127.0.0.1") -> Dict[str, Any]:
        """Verifies submitted challenge response and issues auth token."""
        pass


class SliderCaptchaProvider(CaptchaProvider):
    """Signature Silk-style Interactive Slider Puzzle CAPTCHA Provider."""

    def create_challenge(self, action: str = "register", ip_address: str = "127.0.0.1") -> Dict[str, Any]:
        challenge_data = generate_puzzle_challenge()

        now = datetime.now()
        now_str = now.strftime("%Y-%m-%d %H:%M:%S")
        expires_at = (now + timedelta(seconds=CAPTCHA_TTL_SECONDS)).strftime("%Y-%m-%d %H:%M:%S")

        # Persist correct position and token purely server-side
        execute_db("""
            INSERT INTO captcha_challenges (challenge_id, correct_x, correct_y, action, ip_address, fallback_answer, expires_at, is_used, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)
        """, (
            challenge_data["challenge_id"],
            challenge_data["correct_x"],
            challenge_data["correct_y"],
            action,
            ip_address,
            challenge_data["fallback_answer"],
            expires_at,
            now_str
        ))

        # Omit secret server attributes before sending to browser
        return {
            "success": True,
            "provider": "slider",
            "challenge_id": challenge_data["challenge_id"],
            "bg_image": challenge_data["bg_image"],
            "piece_image": challenge_data["piece_image"],
            "y": challenge_data["piece_y"],
            "piece_y": challenge_data["piece_y"],
            "w": challenge_data["piece_w"],
            "h": challenge_data["piece_h"],
            "fallback_question": challenge_data["fallback_question"]
        }

    def verify(self, payload: Dict[str, Any], ip_address: str = "127.0.0.1") -> Dict[str, Any]:
        challenge_id = payload.get("challenge_id", "")
        final_x = payload.get("final_x", 0)
        trail = payload.get("trail")
        fallback_answer = payload.get("fallback_answer")
        action = payload.get("action", "register")

        return verify_captcha_challenge(
            challenge_id=challenge_id,
            final_x=final_x,
            trail=trail,
            fallback_answer=fallback_answer,
            action=action,
            ip_address=ip_address
        )


class TurnstileCaptchaProvider(CaptchaProvider):
    """Cloudflare Turnstile Provider compatibility adapter."""

    def __init__(self, site_key: str = "", secret_key: str = ""):
        self.site_key = site_key
        self.secret_key = secret_key

    def create_challenge(self, action: str = "register", ip_address: str = "127.0.0.1") -> Dict[str, Any]:
        return {
            "success": True,
            "provider": "turnstile",
            "site_key": self.site_key
        }

    def verify(self, payload: Dict[str, Any], ip_address: str = "127.0.0.1") -> Dict[str, Any]:
        # Client submits Turnstile response token
        response_token = payload.get("turnstile_token", "")
        if response_token:
            token = issue_captcha_token(action=payload.get("action", "register"), ip_address=ip_address)
            return {"success": True, "message": "Turnstile hợp lệ", "captcha_token": token}
        return {"success": False, "message": "Turnstile token không hợp lệ", "captcha_token": None}


class HCaptchaCaptchaProvider(CaptchaProvider):
    """hCaptcha Provider compatibility adapter."""

    def __init__(self, site_key: str = "", secret_key: str = ""):
        self.site_key = site_key
        self.secret_key = secret_key

    def create_challenge(self, action: str = "register", ip_address: str = "127.0.0.1") -> Dict[str, Any]:
        return {
            "success": True,
            "provider": "hcaptcha",
            "site_key": self.site_key
        }

    def verify(self, payload: Dict[str, Any], ip_address: str = "127.0.0.1") -> Dict[str, Any]:
        hcaptcha_token = payload.get("hcaptcha_token", "")
        if hcaptcha_token:
            token = issue_captcha_token(action=payload.get("action", "register"), ip_address=ip_address)
            return {"success": True, "message": "hCaptcha hợp lệ", "captcha_token": token}
        return {"success": False, "message": "hCaptcha token không hợp lệ", "captcha_token": None}


def get_captcha_provider() -> CaptchaProvider:
    """Factory selecting provider based on CAPTCHA_PROVIDER environment setting."""
    p_name = CAPTCHA_PROVIDER.lower()
    if p_name == "turnstile":
        return TurnstileCaptchaProvider()
    elif p_name == "hcaptcha":
        return HCaptchaCaptchaProvider()
    return SliderCaptchaProvider()
